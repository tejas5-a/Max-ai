package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import org.json.JSONArray
import org.json.JSONObject
import org.junit.Assert.assertEquals
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class ExampleRobolectricTest {

    @Test
    fun `read string from context`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val appName = context.getString(R.string.app_name)
        assertEquals("MAX AI", appName)
    }

    @Test
    fun testLiveApi_setupPayloadValidation() {
        val model = "models/gemini-2.5-flash-native-audio-preview-12-2025"
        val voice = "Aoede"

        val setupJson = JSONObject().apply {
            put("setup", JSONObject().apply {
                put("model", model)
                put("generationConfig", JSONObject().apply {
                    put("responseModalities", JSONArray().put("AUDIO"))
                    put("speechConfig", JSONObject().apply {
                        put("voiceConfig", JSONObject().apply {
                            put("prebuiltVoiceConfig", JSONObject().apply {
                                put("voiceName", voice)
                            })
                        })
                    })
                })
            })
        }

        val setupObj = setupJson.getJSONObject("setup")
        assertEquals(model, setupObj.getString("model"))
        val modalities = setupObj.getJSONObject("generationConfig").getJSONArray("responseModalities")
        assertEquals("AUDIO", modalities.getString(0))
        val voiceName = setupObj.getJSONObject("generationConfig")
            .getJSONObject("speechConfig")
            .getJSONObject("voiceConfig")
            .getJSONObject("prebuiltVoiceConfig")
            .getString("voiceName")
        assertEquals("Aoede", voiceName)
    }

    @Test
    fun testLiveApi_realtimeAudioChunkValidation() {
        val fakeBase64 = "UklGRiQAAABXQVZFZm10IBAAAAABAAEAQB8AAEAfAAABAAgAZGF0YQAAAAA="
        val chunkObj = JSONObject().apply {
            put("realtimeInput", JSONObject().apply {
                put("mediaChunks", JSONArray().put(
                    JSONObject().apply {
                        put("mimeType", "audio/pcm;rate=16000")
                        put("data", fakeBase64)
                    }
                ))
            })
        }

        val realtimeInput = chunkObj.getJSONObject("realtimeInput")
        val chunk = realtimeInput.getJSONArray("mediaChunks").getJSONObject(0)
        assertEquals("audio/pcm;rate=16000", chunk.getString("mimeType"))
        assertEquals(fakeBase64, chunk.getString("data"))
    }
}
