package com.example

import com.example.data.model.AssistantMode
import com.example.data.model.PhoneAction
import com.example.data.repository.GeminiRepository
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test

class ExampleUnitTest {

    private val geminiRepo = GeminiRepository()

    @Test
    fun testSystemPrompt_includesAssistantMode() {
        val codingPrompt = geminiRepo.buildSystemPrompt(
            mode = AssistantMode.CODING,
            memories = listOf("User likes Kotlin")
        )
        assertTrue(codingPrompt.contains("senior software architect"))
        assertTrue(codingPrompt.contains("User likes Kotlin"))

        val studyPrompt = geminiRepo.buildSystemPrompt(
            mode = AssistantMode.STUDY,
            memories = emptyList()
        )
        assertTrue(studyPrompt.contains("Socratic tutor"))
    }

    @Test
    fun testActionParsing_openApp() {
        val raw = "I am opening YouTube for you! [ACTION:APP:YouTube]"
        val (cleanText, action) = geminiRepo.extractActionFromText(raw)

        assertEquals("I am opening YouTube for you!", cleanText)
        assertNotNull(action)
        assertTrue(action is PhoneAction.OpenApp)
        assertEquals("YouTube", (action as PhoneAction.OpenApp).appName)
        assertFalse(action.requiresConfirmation)
    }

    @Test
    fun testActionParsing_callRequiresConfirmation() {
        val raw = "I will dial Alice. [ACTION:CALL:5551234:Alice]"
        val (cleanText, action) = geminiRepo.extractActionFromText(raw)

        assertEquals("I will dial Alice.", cleanText)
        assertNotNull(action)
        assertTrue(action is PhoneAction.CallPhone)
        val callAction = action as PhoneAction.CallPhone
        assertEquals("5551234", callAction.phoneNumber)
        assertEquals("Alice", callAction.contactName)
        assertTrue(callAction.requiresConfirmation)
    }

    @Test
    fun testActionParsing_smsRequiresConfirmation() {
        val raw = "Preparing your message. [ACTION:SMS:5559876:Running late]"
        val (cleanText, action) = geminiRepo.extractActionFromText(raw)

        assertEquals("Preparing your message.", cleanText)
        assertNotNull(action)
        assertTrue(action is PhoneAction.SendSms)
        val smsAction = action as PhoneAction.SendSms
        assertEquals("5559876", smsAction.phoneNumber)
        assertEquals("Running late", smsAction.messageBody)
        assertTrue(smsAction.requiresConfirmation)
    }
}
