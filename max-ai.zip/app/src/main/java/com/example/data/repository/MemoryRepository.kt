package com.example.data.repository

import com.example.data.local.AppDatabase
import com.example.data.local.entity.MemoryEntity
import kotlinx.coroutines.flow.Flow

class MemoryRepository(private val db: AppDatabase) {

    fun getAllMemories(): Flow<List<MemoryEntity>> {
        return db.memoryDao().getAllMemories()
    }

    suspend fun getMemoriesList(): List<MemoryEntity> {
        return db.memoryDao().getMemoriesList()
    }

    suspend fun addMemory(content: String, category: String = "general"): Long {
        return db.memoryDao().insertMemory(
            MemoryEntity(
                content = content.trim(),
                category = category
            )
        )
    }

    suspend fun updateMemory(memory: MemoryEntity) {
        db.memoryDao().updateMemory(memory)
    }

    suspend fun deleteMemory(id: Long) {
        db.memoryDao().deleteMemoryById(id)
    }

    suspend fun clearAll() {
        db.memoryDao().clearAllMemories()
    }
}
