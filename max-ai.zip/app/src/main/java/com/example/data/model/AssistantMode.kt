package com.example.data.model

enum class AssistantMode(
    val title: String,
    val subtitle: String,
    val promptBadge: String
) {
    CHAT(
        title = "General Assistant",
        subtitle = "Conversations, questions, ideas & everyday tasks",
        promptBadge = "MAX Chat"
    ),
    CODING(
        title = "Coding Mode",
        subtitle = "Code generation, debugging, refactoring & review",
        promptBadge = "Coding Mode"
    ),
    STUDY(
        title = "Study Mode",
        subtitle = "Step-by-step explanations, concepts & practice questions",
        promptBadge = "Study Mode"
    )
}
