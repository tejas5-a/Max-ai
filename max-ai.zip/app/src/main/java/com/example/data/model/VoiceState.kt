package com.example.data.model

enum class VoiceState(val label: String) {
    READY("Ready"),
    LISTENING("Listening..."),
    THINKING("Thinking..."),
    SPEAKING("Speaking..."),
    ERROR("Error")
}
