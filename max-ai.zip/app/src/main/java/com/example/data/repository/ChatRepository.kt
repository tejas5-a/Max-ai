package com.example.data.repository

import com.example.data.local.AppDatabase
import com.example.data.local.entity.ChatMessageEntity
import com.example.data.local.entity.ConversationEntity
import kotlinx.coroutines.flow.Flow

class ChatRepository(private val db: AppDatabase) {

    fun getAllConversations(): Flow<List<ConversationEntity>> {
        return db.conversationDao().getAllConversations()
    }

    fun searchConversations(query: String): Flow<List<ConversationEntity>> {
        return db.conversationDao().searchConversations(query)
    }

    suspend fun getConversation(id: Long): ConversationEntity? {
        return db.conversationDao().getConversationById(id)
    }

    suspend fun createConversation(title: String, mode: String = "CHAT"): Long {
        val conv = ConversationEntity(
            title = title,
            mode = mode
        )
        return db.conversationDao().insertConversation(conv)
    }

    suspend fun updateConversationTitle(id: Long, newTitle: String) {
        db.conversationDao().updateTitle(id, newTitle)
    }

    suspend fun updateConversationLastMessage(id: Long, lastMessage: String) {
        db.conversationDao().updateLastMessage(id, lastMessage)
    }

    suspend fun deleteConversation(id: Long) {
        db.conversationDao().deleteConversationById(id)
    }

    suspend fun clearAllConversations() {
        db.conversationDao().clearAllConversations()
    }

    fun getMessages(conversationId: Long): Flow<List<ChatMessageEntity>> {
        return db.chatMessageDao().getMessagesForConversation(conversationId)
    }

    suspend fun getMessagesList(conversationId: Long): List<ChatMessageEntity> {
        return db.chatMessageDao().getMessagesList(conversationId)
    }

    suspend fun insertMessage(message: ChatMessageEntity): Long {
        val id = db.chatMessageDao().insertMessage(message)
        db.conversationDao().updateLastMessage(message.conversationId, message.text.take(80))
        return id
    }

    suspend fun updateMessage(message: ChatMessageEntity) {
        db.chatMessageDao().updateMessage(message)
        db.conversationDao().updateLastMessage(message.conversationId, message.text.take(80))
    }

    suspend fun deleteMessage(id: Long) {
        db.chatMessageDao().deleteMessageById(id)
    }
}
