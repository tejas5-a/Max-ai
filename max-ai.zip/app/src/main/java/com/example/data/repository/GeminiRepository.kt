package com.example.data.repository

import android.graphics.Bitmap
import android.util.Base64
import android.util.Log
import com.example.BuildConfig
import com.example.data.model.AssistantMode
import com.example.data.model.PhoneAction
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.flowOn
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.io.InputStream
import java.util.concurrent.TimeUnit

data class GroundingSource(
    val title: String,
    val uri: String
)

data class GeminiResponse(
    val text: String,
    val detectedAction: PhoneAction? = null,
    val sources: List<GroundingSource> = emptyList(),
    val isError: Boolean = false
)

class GeminiRepository {

    private val client = OkHttpClient.Builder()
        .connectTimeout(60, TimeUnit.SECONDS)
        .readTimeout(60, TimeUnit.SECONDS)
        .writeTimeout(60, TimeUnit.SECONDS)
        .build()

    var selectedModel: String = "gemini-3.5-flash"
    var enableWebSearch: Boolean = false

    private fun getApiKey(): String {
        return try {
            BuildConfig.GEMINI_API_KEY
        } catch (e: Exception) {
            ""
        }
    }

    fun isApiKeyConfigured(): Boolean {
        val key = getApiKey()
        return key.isNotBlank() && key != "MY_GEMINI_API_KEY"
    }

    /**
     * Builds the system prompt for MAX AI tailored to personality, mode, and memories.
     */
    fun buildSystemPrompt(
        mode: AssistantMode,
        memories: List<String>
    ): String {
        val basePersonality = """
You are MAX, an intelligent, helpful, and futuristic personal AI assistant.
Your demeanor is courteous, proactive, concise, and clear.
You communicate in the user's preferred language.
When explaining concepts, adapt to the user's level. Admit uncertainty honestly instead of hallucinating.
Do not claim to have performed a phone action, opened an app, or initiated a call unless you output the designated ACTION tag.

Available smart device commands you can trigger:
If the user asks to open an app, settings, make a call, send a text, or search maps, include an action tag at the end of your response:
- [ACTION:APP:YouTube]
- [ACTION:APP:Camera]
- [ACTION:APP:Maps]
- [ACTION:APP:Browser]
- [ACTION:APP:Calculator]
- [ACTION:APP:Calendar]
- [ACTION:APP:Clock]
- [ACTION:SETTINGS:wifi]
- [ACTION:SETTINGS:bluetooth]
- [ACTION:SETTINGS:display]
- [ACTION:SETTINGS:sound]
- [ACTION:SETTINGS:general]
- [ACTION:CALL:phonenumber:contactname]
- [ACTION:SMS:phonenumber:message]
- [ACTION:MAPS:query]
- [ACTION:URL:https://example.com]
Always provide a friendly explanation of what you are doing before the action tag.
""".trimIndent()

        val modeInstruction = when (mode) {
            AssistantMode.CHAT -> "Current Mode: General Assistant. Help with daily tasks, questions, writing, and curiosity."
            AssistantMode.CODING -> """
Current Mode: Coding & Engineering.
You are a senior software architect.
Always provide clean, correct, well-structured code formatted inside markdown code blocks with the language identifier (e.g. ```kotlin ... ```).
Explain key logic, algorithm time/space complexity, and offer edge-case handling or refactoring tips.
""".trimIndent()
            AssistantMode.STUDY -> """
Current Mode: Study & Learning.
You are a patient, inspiring Socratic tutor.
Break down complex academic or technical topics into digestible steps.
Use clear analogies. At the end of an explanation, propose a quick practice question to test understanding.
""".trimIndent()
        }

        val memorySection = if (memories.isNotEmpty()) {
            "\n\nUser Profile & Saved Memories:\n" + memories.joinToString("\n") { "- $it" }
        } else ""

        return "$basePersonality\n\n$modeInstruction$memorySection"
    }

    /**
     * Streams Gemini response using Server-Sent Events (SSE).
     */
    fun streamChat(
        history: List<Pair<String, String>>, // role ("user"/"model") to text
        latestPrompt: String,
        fileBytes: ByteArray? = null,
        fileMimeType: String? = null,
        fileName: String? = null,
        mode: AssistantMode = AssistantMode.CHAT,
        memories: List<String> = emptyList(),
        useSearch: Boolean = enableWebSearch,
        onSourcesExtracted: ((List<GroundingSource>) -> Unit)? = null
    ): Flow<String> = flow {
        val apiKey = getApiKey()
        if (apiKey.isBlank() || apiKey == "MY_GEMINI_API_KEY") {
            emit("⚠️ **Gemini API Key Required**\n\nTo use MAX AI, please enter your Gemini API key in the **Secrets panel** in Google AI Studio (`GEMINI_API_KEY`).")
            return@flow
        }

        val url = "https://generativelanguage.googleapis.com/v1beta/models/$selectedModel:streamGenerateContent?alt=sse&key=$apiKey"
        val requestJson = buildRequestJson(history, latestPrompt, fileBytes, fileMimeType, fileName, mode, memories, useSearch)

        val request = Request.Builder()
            .url(url)
            .post(requestJson.toString().toRequestBody("application/json".toMediaType()))
            .build()

        try {
            client.newCall(request).execute().use { response ->
                if (!response.isSuccessful) {
                    val errorBody = response.body?.string() ?: "Unknown error"
                    val errorMsg = parseErrorMessage(response.code, errorBody)
                    emit("Error (${response.code}): $errorMsg")
                    return@flow
                }

                val body = response.body ?: throw Exception("Empty response body")
                body.byteStream().bufferedReader().use { reader ->
                    var line: String?
                    while (reader.readLine().also { line = it } != null) {
                        val trimmed = line?.trim() ?: continue
                        if (!trimmed.startsWith("data:")) continue
                        val dataContent = trimmed.removePrefix("data:").trim()
                        if (dataContent.isEmpty() || dataContent == "[DONE]") continue

                        try {
                            val chunkObj = JSONObject(dataContent)
                            val text = extractTextFromChunk(chunkObj)
                            if (text.isNotEmpty()) {
                                emit(text)
                            }
                            val sources = extractGroundingSources(chunkObj)
                            if (sources.isNotEmpty()) {
                                onSourcesExtracted?.invoke(sources)
                            }
                        } catch (e: Exception) {
                            Log.w("GeminiRepo", "Error parsing chunk: ${e.message}")
                        }
                    }
                }
            }
        } catch (e: Exception) {
            emit("Network connection error: ${e.localizedMessage ?: "Unable to contact Gemini"}. Please check your internet connection.")
        }
    }.flowOn(Dispatchers.IO)

    /**
     * Non-streaming call, useful for voice replies and single prompt evaluation.
     */
    suspend fun generateResponse(
        history: List<Pair<String, String>>,
        latestPrompt: String,
        fileBytes: ByteArray? = null,
        fileMimeType: String? = null,
        fileName: String? = null,
        mode: AssistantMode = AssistantMode.CHAT,
        memories: List<String> = emptyList(),
        useSearch: Boolean = enableWebSearch
    ): GeminiResponse = withContext(Dispatchers.IO) {
        val apiKey = getApiKey()
        if (apiKey.isBlank() || apiKey == "MY_GEMINI_API_KEY") {
            return@withContext GeminiResponse(
                text = "Gemini API key is not configured. Please set GEMINI_API_KEY in the Secrets panel in AI Studio.",
                isError = true
            )
        }

        val url = "https://generativelanguage.googleapis.com/v1beta/models/$selectedModel:generateContent?key=$apiKey"
        val requestJson = buildRequestJson(history, latestPrompt, fileBytes, fileMimeType, fileName, mode, memories, useSearch)

        val request = Request.Builder()
            .url(url)
            .post(requestJson.toString().toRequestBody("application/json".toMediaType()))
            .build()

        try {
            client.newCall(request).execute().use { response ->
                val bodyStr = response.body?.string() ?: ""
                if (!response.isSuccessful) {
                    val msg = parseErrorMessage(response.code, bodyStr)
                    return@withContext GeminiResponse(text = "Error: $msg", isError = true)
                }

                val json = JSONObject(bodyStr)
                val (rawText, sources) = extractCandidateDetails(json)
                val (cleanText, action) = extractActionFromText(rawText)

                return@withContext GeminiResponse(
                    text = cleanText,
                    detectedAction = action,
                    sources = sources,
                    isError = false
                )
            }
        } catch (e: Exception) {
            return@withContext GeminiResponse(
                text = "Failed to communicate with MAX AI: ${e.message ?: "Unknown error"}",
                isError = true
            )
        }
    }

    private fun buildRequestJson(
        history: List<Pair<String, String>>,
        latestPrompt: String,
        fileBytes: ByteArray?,
        fileMimeType: String?,
        fileName: String?,
        mode: AssistantMode,
        memories: List<String>,
        useSearch: Boolean
    ): JSONObject {
        val root = JSONObject()

        // System Instruction
        val systemObj = JSONObject()
        val sysParts = JSONArray()
        sysParts.put(JSONObject().put("text", buildSystemPrompt(mode, memories)))
        systemObj.put("parts", sysParts)
        root.put("systemInstruction", systemObj)

        // Contents (Multi-turn)
        val contentsArray = JSONArray()

        // Add past turns (limit to last 10 for latency & token economy)
        val recentHistory = history.takeLast(10)
        for ((role, text) in recentHistory) {
            val contentObj = JSONObject()
            contentObj.put("role", if (role == "user") "user" else "model")
            val parts = JSONArray()
            parts.put(JSONObject().put("text", text))
            contentObj.put("parts", parts)
            contentsArray.put(contentObj)
        }

        // Add current turn
        val currentContent = JSONObject()
        currentContent.put("role", "user")
        val currentParts = JSONArray()

        var effectivePrompt = latestPrompt

        // Attachment handling (Image or Document)
        if (fileBytes != null && !fileMimeType.isNullOrBlank()) {
            if (fileMimeType.startsWith("image/") || fileMimeType == "application/pdf") {
                val base64Data = Base64.encodeToString(fileBytes, Base64.NO_WRAP)
                val inlineData = JSONObject()
                    .put("mimeType", fileMimeType)
                    .put("data", base64Data)
                currentParts.put(JSONObject().put("inlineData", inlineData))
            } else if (fileMimeType.startsWith("text/") || fileMimeType == "application/json" || fileMimeType == "text/csv") {
                try {
                    val textContent = String(fileBytes, Charsets.UTF_8)
                    val docHeader = "[Attached File: ${fileName ?: "Document"}]\n$textContent\n---\n"
                    effectivePrompt = docHeader + latestPrompt
                } catch (e: Exception) {
                    Log.w("GeminiRepo", "Could not parse text document: ${e.message}")
                }
            }
        }

        currentParts.put(JSONObject().put("text", effectivePrompt))
        currentContent.put("parts", currentParts)
        contentsArray.put(currentContent)
        root.put("contents", contentsArray)

        // Generation Config
        val genConfig = JSONObject()
        genConfig.put("temperature", if (mode == AssistantMode.CODING) 0.3 else 0.7)
        genConfig.put("topP", 0.95)
        root.put("generationConfig", genConfig)

        // Tools (Google Search Grounding)
        if (useSearch) {
            val toolsArray = JSONArray()
            val googleSearchTool = JSONObject().put("googleSearch", JSONObject())
            toolsArray.put(googleSearchTool)
            root.put("tools", toolsArray)
        }

        return root
    }

    private fun extractGroundingSources(json: JSONObject): List<GroundingSource> {
        val sources = mutableListOf<GroundingSource>()
        val candidates = json.optJSONArray("candidates") ?: return sources
        if (candidates.length() == 0) return sources
        val candidate = candidates.getJSONObject(0)
        val grounding = candidate.optJSONObject("groundingMetadata")
        val chunks = grounding?.optJSONArray("groundingChunks")
        if (chunks != null) {
            for (i in 0 until chunks.length()) {
                val chunk = chunks.getJSONObject(i)
                val web = chunk.optJSONObject("web")
                if (web != null) {
                    val uri = web.optString("uri")
                    val title = web.optString("title", uri)
                    if (uri.isNotBlank()) {
                        sources.add(GroundingSource(title, uri))
                    }
                }
            }
        }
        return sources
    }

    private fun extractTextFromChunk(chunk: JSONObject): String {
        val candidates = chunk.optJSONArray("candidates") ?: return ""
        if (candidates.length() == 0) return ""
        val candidate = candidates.getJSONObject(0)
        val content = candidate.optJSONObject("content") ?: return ""
        val parts = content.optJSONArray("parts") ?: return ""
        val sb = StringBuilder()
        for (i in 0 until parts.length()) {
            val part = parts.getJSONObject(i)
            sb.append(part.optString("text", ""))
        }
        return sb.toString()
    }

    private fun extractCandidateDetails(json: JSONObject): Pair<String, List<GroundingSource>> {
        val candidates = json.optJSONArray("candidates") ?: return Pair("", emptyList())
        if (candidates.length() == 0) return Pair("", emptyList())
        val candidate = candidates.getJSONObject(0)

        // Text
        val content = candidate.optJSONObject("content")
        val parts = content?.optJSONArray("parts")
        val sb = StringBuilder()
        if (parts != null) {
            for (i in 0 until parts.length()) {
                sb.append(parts.getJSONObject(i).optString("text", ""))
            }
        }

        // Sources
        val sources = mutableListOf<GroundingSource>()
        val grounding = candidate.optJSONObject("groundingMetadata")
        val chunks = grounding?.optJSONArray("groundingChunks")
        if (chunks != null) {
            for (i in 0 until chunks.length()) {
                val chunk = chunks.getJSONObject(i)
                val web = chunk.optJSONObject("web")
                if (web != null) {
                    val uri = web.optString("uri")
                    val title = web.optString("title", uri)
                    if (uri.isNotBlank()) {
                        sources.add(GroundingSource(title, uri))
                    }
                }
            }
        }

        return Pair(sb.toString(), sources)
    }

    /**
     * Parses smart action markers like [ACTION:APP:YouTube] from text.
     */
    fun extractActionFromText(rawText: String): Pair<String, PhoneAction?> {
        val regex = Regex("""\[ACTION:([A-Z_]+)(?::([^\]]+))?\]""")
        val match = regex.find(rawText) ?: return Pair(rawText, null)

        val actionType = match.groupValues[1]
        val actionParam = match.groupValues.getOrNull(2) ?: ""

        val action: PhoneAction? = when (actionType) {
            "APP" -> {
                when (actionParam.trim().lowercase()) {
                    "youtube" -> PhoneAction.OpenApp("YouTube", "com.google.android.youtube")
                    "camera" -> PhoneAction.OpenApp("Camera")
                    "maps" -> PhoneAction.OpenApp("Google Maps", "com.google.android.apps.maps")
                    "browser", "chrome" -> PhoneAction.OpenApp("Chrome", "com.android.chrome")
                    "calculator" -> PhoneAction.OpenApp("Calculator")
                    "calendar" -> PhoneAction.OpenApp("Calendar")
                    "clock" -> PhoneAction.OpenApp("Clock")
                    else -> PhoneAction.OpenApp(actionParam.trim())
                }
            }
            "SETTINGS" -> {
                when (actionParam.trim().lowercase()) {
                    "wifi" -> PhoneAction.OpenSettings("Wi-Fi Settings", android.provider.Settings.ACTION_WIFI_SETTINGS)
                    "bluetooth" -> PhoneAction.OpenSettings("Bluetooth Settings", android.provider.Settings.ACTION_BLUETOOTH_SETTINGS)
                    "display" -> PhoneAction.OpenSettings("Display Settings", android.provider.Settings.ACTION_DISPLAY_SETTINGS)
                    "sound" -> PhoneAction.OpenSettings("Sound Settings", android.provider.Settings.ACTION_SOUND_SETTINGS)
                    else -> PhoneAction.OpenSettings("System Settings", android.provider.Settings.ACTION_SETTINGS)
                }
            }
            "CALL" -> {
                val parts = actionParam.split(":")
                val number = parts.getOrNull(0) ?: ""
                val name = parts.getOrNull(1)
                if (number.isNotBlank()) PhoneAction.CallPhone(number, name) else null
            }
            "SMS" -> {
                val parts = actionParam.split(":", limit = 2)
                val number = parts.getOrNull(0) ?: ""
                val body = parts.getOrNull(1) ?: ""
                if (number.isNotBlank()) PhoneAction.SendSms(number, body) else null
            }
            "MAPS" -> {
                if (actionParam.isNotBlank()) PhoneAction.OpenMapLocation(actionParam.trim()) else null
            }
            "URL" -> {
                if (actionParam.isNotBlank()) PhoneAction.OpenWebUrl(actionParam.trim()) else null
            }
            else -> null
        }

        val cleaned = rawText.replace(regex, "").trim()
        return Pair(cleaned, action)
    }

    private fun parseErrorMessage(code: Int, body: String): String {
        return try {
            val json = JSONObject(body)
            val err = json.optJSONObject("error")
            err?.optString("message") ?: when (code) {
                400 -> "Bad Request. The model input was invalid."
                401, 403 -> "Authentication failed. Check your Gemini API Key in the Secrets panel."
                429 -> "Rate limit reached. Please wait a moment and try again."
                500, 503 -> "Google Gemini server temporary error. Please retry."
                else -> "HTTP $code: $body"
            }
        } catch (e: Exception) {
            "HTTP $code error. Please check your network and API configuration."
        }
    }
}
