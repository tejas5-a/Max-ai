package com.example.data.model

sealed class PhoneAction(
    val title: String,
    val description: String,
    val requiresConfirmation: Boolean = false
) {
    data class OpenApp(
        val appName: String,
        val packageName: String? = null
    ) : PhoneAction(
        title = "Open $appName",
        description = "Launch the $appName application on your device",
        requiresConfirmation = false
    )

    data class OpenSettings(
        val settingsType: String,
        val actionIntent: String
    ) : PhoneAction(
        title = "Open $settingsType",
        description = "Open Android system $settingsType screen",
        requiresConfirmation = false
    )

    data class CallPhone(
        val phoneNumber: String,
        val contactName: String? = null
    ) : PhoneAction(
        title = "Call ${contactName ?: phoneNumber}",
        description = "Prepare phone call to $phoneNumber. Confirmation required.",
        requiresConfirmation = true
    )

    data class SendSms(
        val phoneNumber: String,
        val messageBody: String
    ) : PhoneAction(
        title = "Send SMS to $phoneNumber",
        description = "Prepare text message: \"$messageBody\". Confirmation required.",
        requiresConfirmation = true
    )

    data class OpenMapLocation(
        val query: String
    ) : PhoneAction(
        title = "Navigate to $query",
        description = "Search location in Google Maps",
        requiresConfirmation = false
    )

    data class OpenWebUrl(
        val url: String
    ) : PhoneAction(
        title = "Open Website",
        description = "Visit $url in your web browser",
        requiresConfirmation = false
    )
}
