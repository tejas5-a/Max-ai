package com.example.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.Chat
import androidx.compose.material.icons.filled.GraphicEq
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.MicOff
import androidx.compose.material.icons.filled.PanTool
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.VoiceState
import com.example.service.LiveConnectionState
import com.example.ui.components.AiOrb
import com.example.ui.components.AudioWaveform
import com.example.ui.theme.AmberWarning
import com.example.ui.theme.BorderDark
import com.example.ui.theme.CrimsonError
import com.example.ui.theme.CyberPurple
import com.example.ui.theme.CyberViolet
import com.example.ui.theme.DeepMidnight
import com.example.ui.theme.ElectricBlue
import com.example.ui.theme.EmeraldSuccess
import com.example.ui.theme.NeonCyan
import com.example.ui.theme.SurfaceDark
import com.example.ui.theme.SurfaceDarkElevated
import com.example.ui.theme.TextGrayLight
import com.example.ui.theme.TextGrayMuted
import com.example.ui.theme.TextWhite
import com.example.ui.viewmodel.AppScreen
import com.example.ui.viewmodel.MainViewModel

@Composable
fun VoiceAssistantScreen(viewModel: MainViewModel) {
    val isLiveApiSelected by viewModel.useGeminiLiveApi.collectAsState()

    // Live API states
    val liveConnState by viewModel.liveService.connectionState.collectAsState()
    val liveVoiceState by viewModel.liveService.voiceState.collectAsState()
    val liveRms by viewModel.liveService.rmsLevel.collectAsState()
    val liveTranscript by viewModel.liveService.liveTranscript.collectAsState()
    val isLiveMuted by viewModel.liveService.isMuted.collectAsState()
    val liveError by viewModel.liveService.errorMessage.collectAsState()

    // Standard Mode states
    val stdVoiceState by viewModel.voiceState.collectAsState()
    val stdListening by viewModel.speechService.isListening.collectAsState()
    val stdRms by viewModel.speechService.rmsLevel.collectAsState()
    val stdTranscript by viewModel.voiceTranscript.collectAsState()
    val stdSpokenText by viewModel.speechService.spokenText.collectAsState()
    val stdError by viewModel.speechService.errorMessage.collectAsState()

    // Effective display state based on active engine
    val currentVoiceState = if (isLiveApiSelected) liveVoiceState else stdVoiceState
    val currentRms = if (isLiveApiSelected) liveRms else stdRms

    BackHandler {
        if (isLiveApiSelected) viewModel.stopLiveVoiceSession()
        viewModel.navigateTo(AppScreen.HOME)
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(
                Brush.radialGradient(
                    colors = listOf(
                        Color(0xFF131D38),
                        DeepMidnight,
                        Color(0xFF04060C)
                    )
                )
            )
            .statusBarsPadding()
            .navigationBarsPadding()
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(20.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            // Header
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(
                    onClick = {
                        if (isLiveApiSelected) viewModel.stopLiveVoiceSession()
                        viewModel.navigateTo(AppScreen.HOME)
                    },
                    modifier = Modifier.testTag("back_to_chat_button")
                ) {
                    Icon(
                        imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                        contentDescription = "Back",
                        tint = TextWhite
                    )
                }

                // Connection Badge
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .size(8.dp)
                                .clip(CircleShape)
                                .background(
                                    if (!isLiveApiSelected) EmeraldSuccess
                                    else when (liveConnState) {
                                        LiveConnectionState.LIVE -> EmeraldSuccess
                                        LiveConnectionState.CONNECTING -> AmberWarning
                                        LiveConnectionState.ERROR -> CrimsonError
                                        else -> TextGrayMuted
                                    }
                                )
                        )
                        Text(
                            text = if (isLiveApiSelected) liveConnState.label.uppercase() else "VOICE MODE: ACTIVE",
                            color = if (isLiveApiSelected && liveConnState == LiveConnectionState.LIVE) NeonCyan else TextGrayLight,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            letterSpacing = 1.sp
                        )
                    }

                    // Engine Mode Switcher Pill
                    Row(
                        modifier = Modifier
                            .padding(top = 4.dp)
                            .clip(RoundedCornerShape(12.dp))
                            .background(SurfaceDark)
                            .border(1.dp, BorderDark, RoundedCornerShape(12.dp))
                            .clickable {
                                if (isLiveApiSelected) {
                                    viewModel.stopLiveVoiceSession()
                                    viewModel.useGeminiLiveApi.value = false
                                } else {
                                    viewModel.useGeminiLiveApi.value = true
                                    viewModel.startLiveVoiceSession()
                                }
                            }
                            .padding(horizontal = 10.dp, vertical = 4.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = if (isLiveApiSelected) "⚡ Gemini Live API" else "🎙️ Standard Voice Mode",
                            color = ElectricBlue,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Medium
                        )
                    }
                }

                IconButton(
                    onClick = {
                        if (isLiveApiSelected) viewModel.stopLiveVoiceSession()
                        viewModel.navigateTo(AppScreen.HOME)
                    },
                    modifier = Modifier.testTag("switch_to_text_button")
                ) {
                    Icon(
                        imageVector = Icons.AutoMirrored.Filled.Chat,
                        contentDescription = "Chat Mode",
                        tint = TextGrayLight
                    )
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            // Center: Responsive Audio-Reactive AI Orb
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center
            ) {
                AiOrb(
                    state = currentVoiceState,
                    rmsLevel = currentRms,
                    size = 190.dp
                )

                Spacer(modifier = Modifier.height(24.dp))

                // Voice State Badge
                val stateColor = when (currentVoiceState) {
                    VoiceState.READY -> ElectricBlue
                    VoiceState.LISTENING -> NeonCyan
                    VoiceState.THINKING -> CyberPurple
                    VoiceState.SPEAKING -> ElectricBlue
                    VoiceState.ERROR -> CrimsonError
                }

                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(20.dp))
                        .background(SurfaceDark)
                        .border(1.dp, stateColor.copy(alpha = 0.5f), RoundedCornerShape(20.dp))
                        .padding(horizontal = 20.dp, vertical = 7.dp)
                ) {
                    Text(
                        text = if (isLiveApiSelected && isLiveMuted) "MIC MUTED" else currentVoiceState.label.uppercase(),
                        color = if (isLiveApiSelected && isLiveMuted) AmberWarning else stateColor,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 1.5.sp
                    )
                }

                Spacer(modifier = Modifier.height(18.dp))

                // Real-time Audio Waveform
                AudioWaveform(
                    isActive = (currentVoiceState == VoiceState.LISTENING || currentVoiceState == VoiceState.SPEAKING) && !isLiveMuted,
                    rmsLevel = currentRms,
                    barCount = 22,
                    maxHeight = 32.dp,
                    barColor = stateColor
                )
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Live Transcript Card
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(16.dp))
                    .background(SurfaceDark.copy(alpha = 0.85f))
                    .border(1.dp, BorderDark, RoundedCornerShape(16.dp))
                    .padding(14.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text(
                    text = if (isLiveApiSelected) "REAL-TIME TRANSCRIPT (GEMINI LIVE)" else "TRANSCRIPT",
                    color = NeonCyan,
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 1.sp
                )
                Spacer(modifier = Modifier.height(6.dp))

                val displayText = if (isLiveApiSelected) {
                    when {
                        liveError != null -> "Error: $liveError"
                        liveTranscript.isNotBlank() -> liveTranscript
                        liveConnState == LiveConnectionState.CONNECTING -> "Connecting bidirectional audio stream..."
                        currentVoiceState == VoiceState.LISTENING -> "MAX is listening to your voice..."
                        currentVoiceState == VoiceState.SPEAKING -> "MAX is speaking..."
                        else -> "Speak freely. Gemini Live processes audio in real-time."
                    }
                } else {
                    when {
                        stdError != null -> "Notice: $stdError"
                        stdSpokenText.isNotBlank() -> "\"$stdSpokenText\""
                        stdTranscript.isNotBlank() -> "\"$stdTranscript\""
                        currentVoiceState == VoiceState.LISTENING -> "Listening to your voice..."
                        currentVoiceState == VoiceState.SPEAKING -> "MAX is answering..."
                        else -> "Tap the microphone to speak"
                    }
                }

                Text(
                    text = displayText,
                    color = if ((isLiveApiSelected && liveError != null) || (!isLiveApiSelected && stdError != null)) CrimsonError else TextWhite,
                    fontSize = 14.sp,
                    textAlign = TextAlign.Center,
                    lineHeight = 20.sp,
                    maxLines = 4
                )

                // Reconnect action button if connection dropped
                if (isLiveApiSelected && liveConnState == LiveConnectionState.ERROR) {
                    Spacer(modifier = Modifier.height(10.dp))
                    Button(
                        onClick = { viewModel.startLiveVoiceSession() },
                        colors = ButtonDefaults.buttonColors(
                            containerColor = ElectricBlue,
                            contentColor = DeepMidnight
                        ),
                        shape = RoundedCornerShape(10.dp)
                    ) {
                        Icon(Icons.Default.Refresh, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Reconnect Live Session", fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                    }
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Action Controls
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceEvenly,
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Interruption / Barge-in Button (Allows user to interrupt MAX while speaking)
                IconButton(
                    onClick = {
                        if (isLiveApiSelected) {
                            viewModel.interruptLiveVoice()
                        } else {
                            viewModel.ttsService.stop()
                        }
                    },
                    modifier = Modifier
                        .size(52.dp)
                        .clip(CircleShape)
                        .background(SurfaceDarkElevated)
                        .border(1.dp, BorderDark, CircleShape)
                        .testTag("interrupt_voice_button")
                ) {
                    Icon(
                        imageVector = Icons.Default.PanTool,
                        contentDescription = "Interrupt MAX",
                        tint = if (currentVoiceState == VoiceState.SPEAKING) AmberWarning else TextGrayLight,
                        modifier = Modifier.size(22.dp)
                    )
                }

                // Primary Mic / Mute Trigger
                val micActive = if (isLiveApiSelected) !isLiveMuted else stdListening
                Box(
                    modifier = Modifier
                        .size(76.dp)
                        .clip(CircleShape)
                        .background(
                            Brush.linearGradient(
                                if (micActive) listOf(NeonCyan, ElectricBlue)
                                else listOf(ElectricBlue, CyberPurple)
                            )
                        )
                        .border(
                            2.dp,
                            if (micActive) NeonCyan else CyberViolet,
                            CircleShape
                        ),
                    contentAlignment = Alignment.Center
                ) {
                    IconButton(
                        onClick = {
                            if (isLiveApiSelected) {
                                viewModel.toggleLiveVoiceMic()
                            } else {
                                viewModel.toggleVoiceListening()
                            }
                        },
                        modifier = Modifier
                            .fillMaxSize()
                            .testTag("toggle_voice_mic_button")
                    ) {
                        Icon(
                            imageVector = if (micActive) Icons.Default.Mic else Icons.Default.MicOff,
                            contentDescription = "Microphone",
                            tint = DeepMidnight,
                            modifier = Modifier.size(34.dp)
                        )
                    }
                }

                // End Session / Chat Button
                IconButton(
                    onClick = {
                        if (isLiveApiSelected) viewModel.stopLiveVoiceSession()
                        viewModel.navigateTo(AppScreen.HOME)
                    },
                    modifier = Modifier
                        .size(52.dp)
                        .clip(CircleShape)
                        .background(SurfaceDarkElevated)
                        .border(1.dp, BorderDark, CircleShape)
                        .testTag("end_session_button")
                ) {
                    Icon(
                        imageVector = Icons.Default.Stop,
                        contentDescription = "End Session",
                        tint = CrimsonError,
                        modifier = Modifier.size(22.dp)
                    )
                }
            }
        }
    }
}
