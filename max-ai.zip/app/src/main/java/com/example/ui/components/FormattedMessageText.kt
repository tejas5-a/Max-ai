package com.example.ui.components

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.ElectricBlue
import com.example.ui.theme.NeonCyan
import com.example.ui.theme.SurfaceDarkElevated
import com.example.ui.theme.TextGrayLight
import com.example.ui.theme.TextGrayMuted
import com.example.ui.theme.TextWhite

sealed class TextSegment {
    data class Regular(val text: String) : TextSegment()
    data class CodeBlock(val language: String, val code: String) : TextSegment()
}

@Composable
fun FormattedMessageText(
    text: String,
    modifier: Modifier = Modifier,
    textColor: Color = TextWhite
) {
    val segments = remember(text) { parseMessageSegments(text) }

    Column(modifier = modifier, verticalArrangement = Arrangement.spacedBy(8.dp)) {
        for (segment in segments) {
            when (segment) {
                is TextSegment.Regular -> {
                    MarkdownTextRenderer(
                        rawText = segment.text,
                        textColor = textColor
                    )
                }
                is TextSegment.CodeBlock -> {
                    CodeBlockCard(
                        language = segment.language,
                        code = segment.code
                    )
                }
            }
        }
    }
}

private fun parseMessageSegments(rawText: String): List<TextSegment> {
    val segments = mutableListOf<TextSegment>()
    val codeBlockRegex = Regex("""```([a-zA-Z0-9_\-+]*)\n([\s\S]*?)```""")

    var lastIndex = 0
    codeBlockRegex.findAll(rawText).forEach { match ->
        val startIndex = match.range.first
        val endIndex = match.range.last + 1

        if (startIndex > lastIndex) {
            val plain = rawText.substring(lastIndex, startIndex)
            if (plain.isNotBlank()) {
                segments.add(TextSegment.Regular(plain.trim()))
            }
        }

        val lang = match.groupValues[1].ifBlank { "code" }
        val code = match.groupValues[2].trimEnd()
        segments.add(TextSegment.CodeBlock(language = lang, code = code))

        lastIndex = endIndex
    }

    if (lastIndex < rawText.length) {
        val remaining = rawText.substring(lastIndex)
        if (remaining.isNotBlank()) {
            segments.add(TextSegment.Regular(remaining.trim()))
        }
    }

    return if (segments.isEmpty() && rawText.isNotBlank()) {
        listOf(TextSegment.Regular(rawText))
    } else segments
}

@Composable
private fun MarkdownTextRenderer(
    rawText: String,
    textColor: Color
) {
    val lines = rawText.split("\n")
    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
        for (line in lines) {
            val trimmed = line.trim()
            val annotated = buildAnnotatedString {
                // Check if bullet point
                var content = trimmed
                if (content.startsWith("- ") || content.startsWith("* ") || content.startsWith("• ")) {
                    withStyle(SpanStyle(color = ElectricBlue, fontWeight = FontWeight.Bold)) {
                        append("• ")
                    }
                    content = content.substring(2)
                }

                // Parse **bold** parts
                val boldRegex = Regex("""\*\*(.*?)\*\*""")
                var lastIdx = 0
                boldRegex.findAll(content).forEach { match ->
                    val start = match.range.first
                    val end = match.range.last + 1
                    if (start > lastIdx) {
                        append(content.substring(lastIdx, start))
                    }
                    withStyle(SpanStyle(fontWeight = FontWeight.Bold, color = textColor)) {
                        append(match.groupValues[1])
                    }
                    lastIdx = end
                }
                if (lastIdx < content.length) {
                    append(content.substring(lastIdx))
                }
            }

            Text(
                text = annotated,
                color = textColor,
                fontSize = 15.sp,
                lineHeight = 22.sp
            )
        }
    }
}

@Composable
private fun CodeBlockCard(
    language: String,
    code: String
) {
    val context = LocalContext.current
    var copied by remember { mutableStateOf(false) }

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(12.dp))
            .background(Color(0xFF0A0F1D))
    ) {
        // Code Block Header
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .background(SurfaceDarkElevated)
                .padding(horizontal = 12.dp, vertical = 6.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = language.uppercase(),
                color = NeonCyan,
                fontSize = 12.sp,
                fontWeight = FontWeight.SemiBold,
                fontFamily = FontFamily.Monospace
            )

            Row(
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(
                    onClick = {
                        val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                        val clip = ClipData.newPlainText("Code", code)
                        clipboard.setPrimaryClip(clip)
                        copied = true
                        Toast.makeText(context, "Code copied to clipboard", Toast.LENGTH_SHORT).show()
                    },
                    modifier = Modifier
                        .size(32.dp)
                        .testTag("copy_code_button")
                ) {
                    Icon(
                        imageVector = Icons.Default.ContentCopy,
                        contentDescription = "Copy code",
                        tint = if (copied) NeonCyan else TextGrayMuted,
                        modifier = Modifier.size(16.dp)
                    )
                }
                Spacer(modifier = Modifier.width(4.dp))
                Text(
                    text = if (copied) "Copied!" else "Copy",
                    color = if (copied) NeonCyan else TextGrayMuted,
                    fontSize = 11.sp
                )
            }
        }

        // Code Content
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .horizontalScroll(rememberScrollState())
                .padding(14.dp)
        ) {
            Text(
                text = code,
                color = TextWhite,
                fontSize = 13.sp,
                fontFamily = FontFamily.Monospace,
                lineHeight = 19.sp
            )
        }
    }
}
