package com.example.ui.components

import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import com.example.data.model.PhoneAction
import com.example.ui.theme.AmberWarning
import com.example.ui.theme.ElectricBlue
import com.example.ui.theme.SurfaceDarkElevated
import com.example.ui.theme.TextGrayLight
import com.example.ui.theme.TextWhite

@Composable
fun ActionConfirmationDialog(
    action: PhoneAction?,
    onConfirm: () -> Unit,
    onDismiss: () -> Unit
) {
    if (action == null) return

    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = SurfaceDarkElevated,
        icon = {
            Icon(
                imageVector = Icons.Default.Warning,
                contentDescription = "Confirmation",
                tint = AmberWarning
            )
        },
        title = {
            Text(
                text = action.title,
                color = TextWhite
            )
        },
        text = {
            Text(
                text = action.description,
                color = TextGrayLight
            )
        },
        confirmButton = {
            TextButton(
                onClick = onConfirm,
                modifier = Modifier.testTag("confirm_action_button")
            ) {
                Text("Proceed", color = ElectricBlue)
            }
        },
        dismissButton = {
            OutlinedButton(
                onClick = onDismiss,
                modifier = Modifier.testTag("cancel_action_button")
            ) {
                Text("Cancel", color = TextGrayLight)
            }
        }
    )
}
