package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Futuristic Dark Palette (Default)
val DeepMidnight = Color(0xFF070A13)
val DarkNavy = Color(0xFF0F172A)
val SurfaceDark = Color(0xFF131D36)
val SurfaceDarkElevated = Color(0xFF1E293B)
val BorderDark = Color(0xFF26334D)

// Neon / Accent Colors
val ElectricBlue = Color(0xFF38BDF8)
val ElectricBlueDark = Color(0xFF0284C7)
val CyberViolet = Color(0xFF818CF8)
val CyberPurple = Color(0xFFA855F7)
val NeonCyan = Color(0xFF22D3EE)
val NeonMagenta = Color(0xFFE879F9)
val EmeraldSuccess = Color(0xFF10B981)
val AmberWarning = Color(0xFFF59E0B)
val CrimsonError = Color(0xFFEF4444)

// Text Colors
val TextWhite = Color(0xFFF8FAFC)
val TextGrayLight = Color(0xFFCBD5E1)
val TextGrayMuted = Color(0xFF94A3B8)
val TextGrayDark = Color(0xFF64748B)

// Light Theme Palette
val LightBackground = Color(0xFFF8FAFC)
val LightSurface = Color(0xFFFFFFFF)
val LightSurfaceElevated = Color(0xFFF1F5F9)
val LightBorder = Color(0xFFE2E8F0)
val LightTextPrimary = Color(0xFF0F172A)
val LightTextSecondary = Color(0xFF475569)
