package com.example.ui.screens

import android.Manifest
import android.content.pm.PackageManager
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.expandVertically
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.shrinkVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.AttachFile
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Code
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Language
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.School
import androidx.compose.material.icons.filled.Send
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import coil.compose.AsyncImage
import com.example.data.local.entity.ChatMessageEntity
import com.example.data.model.AssistantMode
import com.example.data.model.VoiceState
import com.example.ui.components.AiOrb
import com.example.ui.components.FormattedMessageText
import com.example.ui.theme.BorderDark
import com.example.ui.theme.CyberPurple
import com.example.ui.theme.CyberViolet
import com.example.ui.theme.DeepMidnight
import com.example.ui.theme.ElectricBlue
import com.example.ui.theme.NeonCyan
import com.example.ui.theme.SurfaceDark
import com.example.ui.theme.SurfaceDarkElevated
import com.example.ui.theme.TextGrayLight
import com.example.ui.theme.TextGrayMuted
import com.example.ui.theme.TextWhite
import com.example.ui.viewmodel.AppScreen
import com.example.ui.viewmodel.MainViewModel

@Composable
fun HomeScreen(viewModel: MainViewModel) {
    val context = LocalContext.current
    val currentTitle by viewModel.currentConversationTitle.collectAsState()
    val messages by viewModel.messages.collectAsState()
    val currentMode by viewModel.assistantMode.collectAsState()
    val inputText by viewModel.inputText.collectAsState()
    val attachedImage by viewModel.attachedImage.collectAsState()
    val isGenerating by viewModel.isGenerating.collectAsState()
    val isListening by viewModel.speechService.isListening.collectAsState()
    val webSearchEnabled by viewModel.webSearchEnabled.collectAsState()

    val listState = rememberLazyListState()

    // Scroll to bottom when new messages arrive
    LaunchedEffect(messages.size, isGenerating) {
        if (messages.isNotEmpty()) {
            listState.animateScrollToItem(messages.size - 1)
        }
    }

    // Photo picker launcher
    val photoPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia()
    ) { uri ->
        uri?.let { viewModel.attachImage(it) }
    }

    // Record audio permission launcher
    var hasMicPermission by remember {
        mutableStateOf(
            ContextCompat.checkSelfPermission(
                context,
                Manifest.permission.RECORD_AUDIO
            ) == PackageManager.PERMISSION_GRANTED
        )
    }

    val micPermissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { granted ->
        hasMicPermission = granted
        if (granted) {
            viewModel.toggleVoiceListening()
        }
    }

    Scaffold(
        modifier = Modifier
            .fillMaxSize()
            .statusBarsPadding()
            .navigationBarsPadding()
            .imePadding(),
        containerColor = DeepMidnight,
        topBar = {
            HomeTopBar(
                title = currentTitle,
                mode = currentMode,
                onModeSelected = { viewModel.setAssistantMode(it) },
                onNewChat = { viewModel.startNewConversation() },
                onOpenVoice = {
                    if (hasMicPermission) {
                        viewModel.navigateTo(AppScreen.VOICE)
                    } else {
                        micPermissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
                    }
                },
                onOpenHistory = { viewModel.navigateTo(AppScreen.HISTORY) },
                onOpenSettings = { viewModel.navigateTo(AppScreen.SETTINGS) }
            )
        },
        bottomBar = {
            MessageComposer(
                inputText = inputText,
                onTextChanged = { viewModel.setInputText(it) },
                onSend = { viewModel.sendMessage() },
                onCancelGeneration = { viewModel.cancelGeneration() },
                isGenerating = isGenerating,
                isListening = isListening,
                attachedImageUri = attachedImage?.uri,
                onRemoveImage = { viewModel.removeAttachedImage() },
                onPickImage = {
                    photoPickerLauncher.launch(
                        PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
                    )
                },
                onToggleMic = {
                    if (hasMicPermission) {
                        viewModel.toggleVoiceListening()
                    } else {
                        micPermissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
                    }
                },
                webSearchEnabled = webSearchEnabled,
                onToggleWebSearch = { viewModel.webSearchEnabled.value = !webSearchEnabled },
                onOpenVoiceScreen = {
                    if (hasMicPermission) {
                        viewModel.navigateTo(AppScreen.VOICE)
                    } else {
                        micPermissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
                    }
                }
            )
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            if (messages.isEmpty()) {
                WelcomeView(
                    onSuggestedPrompt = { prompt ->
                        viewModel.sendMessage(prompt)
                    },
                    onOpenVoice = {
                        if (hasMicPermission) {
                            viewModel.navigateTo(AppScreen.VOICE)
                        } else {
                            micPermissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
                        }
                    },
                    onSelectMode = { mode ->
                        viewModel.setAssistantMode(mode)
                    },
                    onAnalyzeImage = {
                        photoPickerLauncher.launch(
                            PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
                        )
                    }
                )
            } else {
                LazyColumn(
                    state = listState,
                    modifier = Modifier.fillMaxSize(),
                    contentPadding = PaddingValues(horizontal = 16.dp, vertical = 12.dp),
                    verticalArrangement = Arrangement.spacedBy(14.dp)
                ) {
                    items(messages, key = { it.id }) { message ->
                        ChatMessageItem(
                            message = message,
                            onSpeak = { viewModel.speakMessage(message.text) }
                        )
                    }

                    if (isGenerating) {
                        item {
                            GeneratingIndicator(onStop = { viewModel.cancelGeneration() })
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun HomeTopBar(
    title: String,
    mode: AssistantMode,
    onModeSelected: (AssistantMode) -> Unit,
    onNewChat: () -> Unit,
    onOpenVoice: () -> Unit,
    onOpenHistory: () -> Unit,
    onOpenSettings: () -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .background(DeepMidnight)
            .padding(horizontal = 16.dp, vertical = 8.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            // App Branding
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Box(
                    modifier = Modifier
                        .size(36.dp)
                        .clip(CircleShape)
                        .background(
                            Brush.linearGradient(listOf(ElectricBlue, CyberPurple))
                        ),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.AutoAwesome,
                        contentDescription = "MAX Logo",
                        tint = DeepMidnight,
                        modifier = Modifier.size(20.dp)
                    )
                }
                Column {
                    Text(
                        text = "MAX AI",
                        color = TextWhite,
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 1.sp
                    )
                    Text(
                        text = title,
                        color = TextGrayMuted,
                        fontSize = 12.sp,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }
            }

            // Top Actions
            Row(verticalAlignment = Alignment.CenterVertically) {
                IconButton(
                    onClick = onOpenVoice,
                    modifier = Modifier.testTag("open_voice_screen_button")
                ) {
                    Icon(
                        imageVector = Icons.Default.Mic,
                        contentDescription = "Live Voice Mode",
                        tint = NeonCyan
                    )
                }

                IconButton(
                    onClick = onNewChat,
                    modifier = Modifier.testTag("new_chat_button")
                ) {
                    Icon(
                        imageVector = Icons.Default.Add,
                        contentDescription = "New Conversation",
                        tint = ElectricBlue
                    )
                }

                IconButton(
                    onClick = onOpenHistory,
                    modifier = Modifier.testTag("history_button")
                ) {
                    Icon(
                        imageVector = Icons.Default.History,
                        contentDescription = "History",
                        tint = TextGrayLight
                    )
                }

                IconButton(
                    onClick = onOpenSettings,
                    modifier = Modifier.testTag("settings_button")
                ) {
                    Icon(
                        imageVector = Icons.Default.Settings,
                        contentDescription = "Settings",
                        tint = TextGrayLight
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(8.dp))

        // Mode Selector Pills
        LazyRow(
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            items(AssistantMode.values()) { m ->
                val isSelected = m == mode
                FilterChip(
                    selected = isSelected,
                    onClick = { onModeSelected(m) },
                    label = {
                        Text(
                            text = m.promptBadge,
                            fontSize = 12.sp,
                            fontWeight = if (isSelected) FontWeight.SemiBold else FontWeight.Normal
                        )
                    },
                    leadingIcon = {
                        when (m) {
                            AssistantMode.CHAT -> Icon(
                                Icons.Default.AutoAwesome,
                                contentDescription = null,
                                modifier = Modifier.size(14.dp)
                            )
                            AssistantMode.CODING -> Icon(
                                Icons.Default.Code,
                                contentDescription = null,
                                modifier = Modifier.size(14.dp)
                            )
                            AssistantMode.STUDY -> Icon(
                                Icons.Default.School,
                                contentDescription = null,
                                modifier = Modifier.size(14.dp)
                            )
                        }
                    },
                    colors = FilterChipDefaults.filterChipColors(
                        selectedContainerColor = SurfaceDarkElevated,
                        selectedLabelColor = ElectricBlue,
                        selectedLeadingIconColor = ElectricBlue,
                        containerColor = SurfaceDark,
                        labelColor = TextGrayMuted,
                        iconColor = TextGrayMuted
                    ),
                    border = FilterChipDefaults.filterChipBorder(
                        borderColor = if (isSelected) ElectricBlue.copy(alpha = 0.5f) else BorderDark,
                        selectedBorderColor = ElectricBlue,
                        enabled = true,
                        selected = isSelected
                    )
                )
            }
        }
    }
}

@Composable
private fun WelcomeView(
    onSuggestedPrompt: (String) -> Unit,
    onOpenVoice: () -> Unit,
    onSelectMode: (AssistantMode) -> Unit,
    onAnalyzeImage: () -> Unit
) {
    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(20.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(18.dp)
    ) {
        item {
            Spacer(modifier = Modifier.height(10.dp))
            // Interactive Glowing Orb
            AiOrb(
                state = VoiceState.READY,
                size = 140.dp
            )
        }

        item {
            Text(
                text = "Hello, I'm MAX.",
                color = TextWhite,
                fontSize = 28.sp,
                fontWeight = FontWeight.Bold,
                textAlign = TextAlign.Center
            )
            Spacer(modifier = Modifier.height(6.dp))
            Text(
                text = "Your personal AI assistant. What can I help you with today?",
                color = TextGrayMuted,
                fontSize = 15.sp,
                textAlign = TextAlign.Center,
                lineHeight = 22.sp
            )
        }

        item {
            Text(
                text = "Suggested Actions",
                color = NeonCyan,
                fontSize = 13.sp,
                fontWeight = FontWeight.SemiBold,
                letterSpacing = 1.sp,
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(top = 10.dp)
            )
        }

        val suggestions = listOf(
            Triple("Ask MAX anything", "General questions, daily advice, ideas", AssistantMode.CHAT),
            Triple("Explain a difficult topic", "Learn quantum physics, calculus, or history", AssistantMode.STUDY),
            Triple("Help me write something", "Draft emails, articles, essays & messages", AssistantMode.CHAT),
            Triple("Analyze an image", "Inspect visual diagrams, math problems or photos", AssistantMode.CHAT),
            Triple("Help me with coding", "Generate, debug & review code blocks", AssistantMode.CODING),
            Triple("Search the web", "Find current facts with Google Search grounding", AssistantMode.CHAT),
            Triple("Talk to MAX", "Start futuristic live voice conversation", AssistantMode.CHAT)
        )

        items(suggestions) { (title, subtitle, mode) ->
            SuggestionActionCard(
                title = title,
                subtitle = subtitle,
                onClick = {
                    when (title) {
                        "Talk to MAX" -> onOpenVoice()
                        "Analyze an image" -> onAnalyzeImage()
                        "Help me with coding" -> {
                            onSelectMode(AssistantMode.CODING)
                            onSuggestedPrompt("How can you help me write clean and robust code today?")
                        }
                        "Explain a difficult topic" -> {
                            onSelectMode(AssistantMode.STUDY)
                            onSuggestedPrompt("Can you teach me a complex concept step-by-step?")
                        }
                        else -> {
                            onSelectMode(mode)
                            onSuggestedPrompt(title)
                        }
                    }
                }
            )
        }
    }
}

@Composable
private fun SuggestionActionCard(
    title: String,
    subtitle: String,
    onClick: () -> Unit
) {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(16.dp))
            .background(SurfaceDark)
            .border(1.dp, BorderDark, RoundedCornerShape(16.dp))
            .clickable(onClick = onClick)
            .padding(horizontal = 18.dp, vertical = 14.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = title,
                    color = TextWhite,
                    fontSize = 15.sp,
                    fontWeight = FontWeight.SemiBold
                )
                Spacer(modifier = Modifier.height(2.dp))
                Text(
                    text = subtitle,
                    color = TextGrayMuted,
                    fontSize = 12.sp
                )
            }
            Icon(
                imageVector = Icons.Default.AutoAwesome,
                contentDescription = null,
                tint = ElectricBlue,
                modifier = Modifier.size(18.dp)
            )
        }
    }
}

@Composable
private fun ChatMessageItem(
    message: ChatMessageEntity,
    onSpeak: () -> Unit
) {
    val isUser = message.role == "user"

    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = if (isUser) Arrangement.End else Arrangement.Start
    ) {
        if (!isUser) {
            Box(
                modifier = Modifier
                    .size(32.dp)
                    .clip(CircleShape)
                    .background(Brush.linearGradient(listOf(ElectricBlue, CyberPurple))),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.Default.AutoAwesome,
                    contentDescription = "MAX",
                    tint = DeepMidnight,
                    modifier = Modifier.size(16.dp)
                )
            }
            Spacer(modifier = Modifier.width(8.dp))
        }

        Column(
            modifier = Modifier.fillMaxWidth(if (isUser) 0.85f else 0.92f),
            horizontalAlignment = if (isUser) Alignment.End else Alignment.Start
        ) {
            // Attached image if user uploaded one
            if (!message.imageUri.isNullOrBlank()) {
                AsyncImage(
                    model = message.imageUri,
                    contentDescription = "Uploaded image",
                    modifier = Modifier
                        .padding(bottom = 6.dp)
                        .size(180.dp)
                        .clip(RoundedCornerShape(12.dp))
                        .border(1.dp, BorderDark, RoundedCornerShape(12.dp)),
                    contentScale = ContentScale.Crop
                )
            }

            Box(
                modifier = Modifier
                    .clip(
                        RoundedCornerShape(
                            topStart = 16.dp,
                            topEnd = 16.dp,
                            bottomStart = if (isUser) 16.dp else 4.dp,
                            bottomEnd = if (isUser) 4.dp else 16.dp
                        )
                    )
                    .background(
                        if (isUser) {
                            Brush.linearGradient(listOf(Color(0xFF1E3A8A), Color(0xFF2563EB)))
                        } else {
                            Brush.linearGradient(listOf(SurfaceDark, SurfaceDarkElevated))
                        }
                    )
                    .border(
                        1.dp,
                        if (isUser) ElectricBlue.copy(alpha = 0.4f) else BorderDark,
                        RoundedCornerShape(16.dp)
                    )
                    .padding(14.dp)
            ) {
                if (isUser) {
                    Text(
                        text = message.text,
                        color = TextWhite,
                        fontSize = 15.sp,
                        lineHeight = 22.sp
                    )
                } else {
                    FormattedMessageText(
                        text = message.text,
                        textColor = TextWhite
                    )
                }
            }

            // Speak button for model replies
            if (!isUser && message.text.isNotBlank()) {
                Row(
                    modifier = Modifier.padding(top = 4.dp, start = 4.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    IconButton(
                        onClick = onSpeak,
                        modifier = Modifier.size(28.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.VolumeUp,
                            contentDescription = "Speak response",
                            tint = TextGrayMuted,
                            modifier = Modifier.size(16.dp)
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun GeneratingIndicator(onStop: () -> Unit) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 8.dp),
        horizontalArrangement = Arrangement.Start,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            modifier = Modifier
                .clip(RoundedCornerShape(20.dp))
                .background(SurfaceDarkElevated)
                .border(1.dp, BorderDark, RoundedCornerShape(20.dp))
                .padding(horizontal = 14.dp, vertical = 8.dp),
            contentAlignment = Alignment.Center
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                CircularProgressIndicator(
                    modifier = Modifier.size(16.dp),
                    color = NeonCyan,
                    strokeWidth = 2.dp
                )
                Text(
                    text = "MAX is thinking...",
                    color = NeonCyan,
                    fontSize = 13.sp
                )
                Spacer(modifier = Modifier.width(4.dp))
                IconButton(
                    onClick = onStop,
                    modifier = Modifier.size(24.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.Stop,
                        contentDescription = "Stop",
                        tint = TextGrayMuted,
                        modifier = Modifier.size(16.dp)
                    )
                }
            }
        }
    }
}

@Composable
private fun MessageComposer(
    inputText: String,
    onTextChanged: (String) -> Unit,
    onSend: () -> Unit,
    onCancelGeneration: () -> Unit,
    isGenerating: Boolean,
    isListening: Boolean,
    attachedImageUri: android.net.Uri?,
    onRemoveImage: () -> Unit,
    onPickImage: () -> Unit,
    onToggleMic: () -> Unit,
    webSearchEnabled: Boolean,
    onToggleWebSearch: () -> Unit,
    onOpenVoiceScreen: () -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .background(DeepMidnight)
            .padding(horizontal = 12.dp, vertical = 8.dp)
    ) {
        // Thumbnail of attached image
        AnimatedVisibility(
            visible = attachedImageUri != null,
            enter = expandVertically() + fadeIn(),
            exit = shrinkVertically() + fadeOut()
        ) {
            attachedImageUri?.let { uri ->
                Box(
                    modifier = Modifier
                        .padding(bottom = 8.dp)
                        .size(68.dp)
                        .clip(RoundedCornerShape(8.dp))
                        .border(1.dp, ElectricBlue, RoundedCornerShape(8.dp))
                ) {
                    AsyncImage(
                        model = uri,
                        contentDescription = "Attached thumbnail",
                        modifier = Modifier.fillMaxSize(),
                        contentScale = ContentScale.Crop
                    )
                    IconButton(
                        onClick = onRemoveImage,
                        modifier = Modifier
                            .align(Alignment.TopEnd)
                            .size(24.dp)
                            .background(Color.Black.copy(alpha = 0.6f), CircleShape)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Close,
                            contentDescription = "Remove",
                            tint = Color.White,
                            modifier = Modifier.size(14.dp)
                        )
                    }
                }
            }
        }

        // Input Field & Action Buttons
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            // Attachment button
            IconButton(
                onClick = onPickImage,
                modifier = Modifier
                    .size(42.dp)
                    .testTag("attach_image_button")
            ) {
                Icon(
                    imageVector = Icons.Default.AttachFile,
                    contentDescription = "Attach image",
                    tint = if (attachedImageUri != null) NeonCyan else TextGrayMuted
                )
            }

            // Web search toggle button
            IconButton(
                onClick = onToggleWebSearch,
                modifier = Modifier
                    .size(42.dp)
                    .testTag("web_search_toggle_button")
            ) {
                Icon(
                    imageVector = Icons.Default.Language,
                    contentDescription = "Web Search Grounding",
                    tint = if (webSearchEnabled) ElectricBlue else TextGrayMuted
                )
            }

            // Text Input
            OutlinedTextField(
                value = inputText,
                onValueChange = onTextChanged,
                modifier = Modifier
                    .weight(1f)
                    .testTag("message_input_field"),
                placeholder = {
                    Text(
                        text = if (isListening) "Listening to your voice..." else "Ask MAX anything...",
                        color = TextGrayMuted,
                        fontSize = 14.sp
                    )
                },
                maxLines = 4,
                shape = RoundedCornerShape(24.dp),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedTextColor = TextWhite,
                    unfocusedTextColor = TextWhite,
                    focusedContainerColor = SurfaceDark,
                    unfocusedContainerColor = SurfaceDark,
                    focusedBorderColor = ElectricBlue,
                    unfocusedBorderColor = BorderDark
                )
            )

            // Mic or Send button
            if (inputText.isNotBlank() || attachedImageUri != null) {
                IconButton(
                    onClick = {
                        if (isGenerating) onCancelGeneration() else onSend()
                    },
                    modifier = Modifier
                        .size(44.dp)
                        .clip(CircleShape)
                        .background(if (isGenerating) CyberPurple else ElectricBlue)
                        .testTag("send_message_button")
                ) {
                    Icon(
                        imageVector = if (isGenerating) Icons.Default.Stop else Icons.Default.Send,
                        contentDescription = "Send",
                        tint = DeepMidnight,
                        modifier = Modifier.size(20.dp)
                    )
                }
            } else {
                IconButton(
                    onClick = onToggleMic,
                    modifier = Modifier
                        .size(44.dp)
                        .clip(CircleShape)
                        .background(if (isListening) NeonCyan else SurfaceDarkElevated)
                        .border(1.dp, if (isListening) NeonCyan else BorderDark, CircleShape)
                        .testTag("mic_button")
                ) {
                    Icon(
                        imageVector = Icons.Default.Mic,
                        contentDescription = "Voice Input",
                        tint = if (isListening) DeepMidnight else ElectricBlue,
                        modifier = Modifier.size(20.dp)
                    )
                }
            }
        }
    }
}
