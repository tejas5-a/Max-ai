package com.example.ui.components

import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.size
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.example.data.model.VoiceState
import com.example.ui.theme.CrimsonError
import com.example.ui.theme.CyberPurple
import com.example.ui.theme.CyberViolet
import com.example.ui.theme.ElectricBlue
import com.example.ui.theme.NeonCyan
import kotlin.math.cos
import kotlin.math.sin

@Composable
fun AiOrb(
    state: VoiceState = VoiceState.READY,
    rmsLevel: Float = 0f,
    size: Dp = 140.dp,
    modifier: Modifier = Modifier
) {
    val infiniteTransition = rememberInfiniteTransition(label = "orb_transition")

    // Rotation angle
    val rotation by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 360f,
        animationSpec = infiniteRepeatable(
            animation = tween(
                durationMillis = when (state) {
                    VoiceState.THINKING -> 2000
                    VoiceState.SPEAKING -> 4000
                    VoiceState.LISTENING -> 3500
                    else -> 8000
                },
                easing = LinearEasing
            ),
            repeatMode = RepeatMode.Restart
        ),
        label = "rotation"
    )

    // Pulse scale
    val pulse by infiniteTransition.animateFloat(
        initialValue = 0.92f,
        targetValue = 1.08f,
        animationSpec = infiniteRepeatable(
            animation = tween(
                durationMillis = when (state) {
                    VoiceState.THINKING -> 600
                    VoiceState.SPEAKING -> 800
                    VoiceState.LISTENING -> 900
                    else -> 1800
                },
                easing = FastOutSlowInEasing
            ),
            repeatMode = RepeatMode.Reverse
        ),
        label = "pulse"
    )

    // Color tones based on VoiceState
    val (primaryColor, secondaryColor, coreColor) = when (state) {
        VoiceState.READY -> Triple(ElectricBlue, CyberViolet, NeonCyan)
        VoiceState.LISTENING -> Triple(NeonCyan, ElectricBlue, Color.White)
        VoiceState.THINKING -> Triple(CyberPurple, CyberViolet, NeonCyan)
        VoiceState.SPEAKING -> Triple(ElectricBlue, NeonCyan, Color.White)
        VoiceState.ERROR -> Triple(CrimsonError, Color(0xFFF97316), Color.White)
    }

    Box(
        modifier = modifier.size(size),
        contentAlignment = Alignment.Center
    ) {
        Canvas(modifier = Modifier.size(size)) {
            val center = Offset(this.size.width / 2f, this.size.height / 2f)
            val radius = (this.size.minDimension / 2f) * 0.72f

            // Dynamic scale modulated by audio input RMS level when listening
            val audioScaleBoost = if (state == VoiceState.LISTENING) rmsLevel * 0.25f else 0f
            val effectiveScale = pulse + audioScaleBoost
            val effectiveRadius = radius * effectiveScale

            // 1. Outer Glowing Ambient Halo
            drawCircle(
                brush = Brush.radialGradient(
                    colors = listOf(
                        primaryColor.copy(alpha = 0.45f),
                        secondaryColor.copy(alpha = 0.2f),
                        Color.Transparent
                    ),
                    center = center,
                    radius = effectiveRadius * 1.55f
                ),
                radius = effectiveRadius * 1.55f,
                center = center
            )

            // 2. Rotating Elliptical Orbital Rings
            rotate(rotation, pivot = center) {
                // Orbital Ring 1
                drawOval(
                    color = primaryColor.copy(alpha = 0.75f),
                    topLeft = Offset(center.x - effectiveRadius * 1.25f, center.y - effectiveRadius * 0.65f),
                    size = androidx.compose.ui.geometry.Size(effectiveRadius * 2.5f, effectiveRadius * 1.3f),
                    style = Stroke(width = 3.dp.toPx())
                )
            }

            rotate(-rotation * 0.85f + 45f, pivot = center) {
                // Orbital Ring 2
                drawOval(
                    color = secondaryColor.copy(alpha = 0.7f),
                    topLeft = Offset(center.x - effectiveRadius * 0.7f, center.y - effectiveRadius * 1.25f),
                    size = androidx.compose.ui.geometry.Size(effectiveRadius * 1.4f, effectiveRadius * 2.5f),
                    style = Stroke(width = 2.5.dp.toPx())
                )
            }

            // 3. Main Spherical Core with Multi-stop Gradient
            drawCircle(
                brush = Brush.radialGradient(
                    colors = listOf(
                        coreColor.copy(alpha = 0.95f),
                        primaryColor.copy(alpha = 0.85f),
                        secondaryColor.copy(alpha = 0.65f),
                        Color(0xFF0F172A).copy(alpha = 0.2f)
                    ),
                    center = center.copy(y = center.y - effectiveRadius * 0.15f),
                    radius = effectiveRadius
                ),
                radius = effectiveRadius,
                center = center
            )

            // 4. Central Neural Spark Points
            val numParticles = 4
            for (i in 0 until numParticles) {
                val angle = Math.toRadians((rotation * 1.5 + (i * 90.0))).toFloat()
                val particleDist = effectiveRadius * 0.45f
                val px = center.x + particleDist * cos(angle.toDouble()).toFloat()
                val py = center.y + particleDist * sin(angle.toDouble()).toFloat()
                drawCircle(
                    color = Color.White.copy(alpha = 0.85f),
                    radius = 3.5.dp.toPx(),
                    center = Offset(px, py)
                )
            }
        }
    }
}
