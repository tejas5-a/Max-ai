package com.example.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.ArrowForwardIos
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.DarkMode
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Key
import androidx.compose.material.icons.filled.Psychology
import androidx.compose.material.icons.filled.RecordVoiceOver
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.RadioButton
import androidx.compose.material3.RadioButtonDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.BorderDark
import com.example.ui.theme.CrimsonError
import com.example.ui.theme.DeepMidnight
import com.example.ui.theme.ElectricBlue
import com.example.ui.theme.EmeraldSuccess
import com.example.ui.theme.NeonCyan
import com.example.ui.theme.SurfaceDark
import com.example.ui.theme.SurfaceDarkElevated
import com.example.ui.theme.TextGrayLight
import com.example.ui.theme.TextGrayMuted
import com.example.ui.theme.TextWhite
import com.example.ui.viewmodel.AppScreen
import com.example.ui.viewmodel.MainViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsScreen(viewModel: MainViewModel) {
    val isDarkTheme by viewModel.isDarkTheme.collectAsState()
    val autoSpeak by viewModel.autoSpeakResponses.collectAsState()
    val isMemoryEnabled by viewModel.isMemoryEnabled.collectAsState()
    val memories by viewModel.memories.collectAsState()

    var speechPitch by remember { mutableFloatStateOf(viewModel.ttsService.speechPitch) }
    var speechRate by remember { mutableFloatStateOf(viewModel.ttsService.speechRate) }
    var selectedModel by remember { mutableStateOf(viewModel.geminiRepo.selectedModel) }
    var showClearHistoryDialog by remember { mutableStateOf(false) }

    val isKeyConfigured = remember { viewModel.geminiRepo.isApiKeyConfigured() }

    BackHandler {
        viewModel.navigateTo(AppScreen.HOME)
    }

    Scaffold(
        modifier = Modifier
            .fillMaxSize()
            .statusBarsPadding()
            .navigationBarsPadding(),
        containerColor = DeepMidnight,
        topBar = {
            TopAppBar(
                title = {
                    Text(
                        text = "Settings",
                        color = TextWhite,
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Bold
                    )
                },
                navigationIcon = {
                    IconButton(
                        onClick = { viewModel.navigateTo(AppScreen.HOME) },
                        modifier = Modifier.testTag("settings_back_button")
                    ) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = "Back",
                            tint = TextWhite
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = DeepMidnight)
            )
        }
    ) { innerPadding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // API Key Status Card
            item {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(16.dp))
                        .background(SurfaceDark)
                        .border(
                            1.dp,
                            if (isKeyConfigured) EmeraldSuccess.copy(alpha = 0.5f) else CrimsonError.copy(alpha = 0.5f),
                            RoundedCornerShape(16.dp)
                        )
                        .padding(16.dp)
                ) {
                    Column {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Icon(
                                imageVector = if (isKeyConfigured) Icons.Default.CheckCircle else Icons.Default.Key,
                                contentDescription = null,
                                tint = if (isKeyConfigured) EmeraldSuccess else CrimsonError,
                                modifier = Modifier.size(20.dp)
                            )
                            Text(
                                text = if (isKeyConfigured) "Gemini API: Connected" else "Gemini API Key Required",
                                color = TextWhite,
                                fontSize = 15.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = if (isKeyConfigured)
                                "MAX AI is linked to Google Gemini. Real-time reasoning and multimodal intelligence are operational."
                            else
                                "Please add your GEMINI_API_KEY in the Secrets panel in AI Studio so MAX AI can generate responses.",
                            color = TextGrayLight,
                            fontSize = 13.sp,
                            lineHeight = 18.sp
                        )
                    }
                }
            }

            // AI Model Configuration
            item {
                SettingsSectionHeader("AI MODEL SELECTION")
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(16.dp))
                        .background(SurfaceDark)
                        .border(1.dp, BorderDark, RoundedCornerShape(16.dp))
                        .padding(14.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    val models = listOf(
                        Triple("gemini-3.5-flash", "Gemini 3.5 Flash", "Default: Ultra-fast, comprehensive reasoning & multimodal"),
                        Triple("gemini-3.8-flash", "Gemini 3.8 Flash", "Live conversational model for real-time responsiveness"),
                        Triple("gemini-3.1-pro-preview", "Gemini 3.1 Pro", "Deep logical thinking, advanced math & complex coding")
                    )

                    models.forEach { (id, name, desc) ->
                        val isSelected = selectedModel == id
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(10.dp))
                                .clickable {
                                    selectedModel = id
                                    viewModel.geminiRepo.selectedModel = id
                                }
                                .padding(8.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            RadioButton(
                                selected = isSelected,
                                onClick = {
                                    selectedModel = id
                                    viewModel.geminiRepo.selectedModel = id
                                },
                                colors = RadioButtonDefaults.colors(
                                    selectedColor = ElectricBlue,
                                    unselectedColor = TextGrayMuted
                                )
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Column {
                                Text(
                                    text = name,
                                    color = TextWhite,
                                    fontSize = 14.sp,
                                    fontWeight = FontWeight.SemiBold
                                )
                                Text(
                                    text = desc,
                                    color = TextGrayMuted,
                                    fontSize = 11.sp
                                )
                            }
                        }
                    }
                }
            }

            // Voice & Speech Settings
            item {
                SettingsSectionHeader("VOICE & AUDIO (GEMINI LIVE)")
                val useLiveApi by viewModel.useGeminiLiveApi.collectAsState()
                var selectedVoice by remember { mutableStateOf(viewModel.liveService.selectedVoiceName) }

                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(16.dp))
                        .background(SurfaceDark)
                        .border(1.dp, BorderDark, RoundedCornerShape(16.dp))
                        .padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(16.dp)
                ) {
                    // Gemini Live API Toggle
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text("Gemini Live API", color = TextWhite, fontSize = 14.sp, fontWeight = FontWeight.SemiBold)
                            Text("Ultra-low latency bidirectional audio streaming with interruptions", color = TextGrayMuted, fontSize = 12.sp)
                        }
                        Switch(
                            checked = useLiveApi,
                            onCheckedChange = { viewModel.useGeminiLiveApi.value = it },
                            colors = SwitchDefaults.colors(
                                checkedThumbColor = DeepMidnight,
                                checkedTrackColor = ElectricBlue,
                                uncheckedThumbColor = TextGrayMuted,
                                uncheckedTrackColor = SurfaceDarkElevated
                            )
                        )
                    }

                    // Prebuilt Voice Persona Picker for Live API
                    Column {
                        Text("Live Persona Voice", color = TextWhite, fontSize = 13.sp, fontWeight = FontWeight.Medium)
                        Spacer(modifier = Modifier.height(6.dp))
                        val liveVoices = listOf(
                            Pair("Aoede", "Aoede (Warm & Expressive)"),
                            Pair("Puck", "Puck (Upbeat & Curious)"),
                            Pair("Charon", "Charon (Calm & Resonant)"),
                            Pair("Kore", "Kore (Clear & Gentle)"),
                            Pair("Fenrir", "Fenrir (Confident & Direct)")
                        )
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            liveVoices.take(3).forEach { (id, label) ->
                                val isVSelected = selectedVoice == id
                                Box(
                                    modifier = Modifier
                                        .clip(RoundedCornerShape(8.dp))
                                        .background(if (isVSelected) SurfaceDarkElevated else Color.Transparent)
                                        .border(1.dp, if (isVSelected) ElectricBlue else BorderDark, RoundedCornerShape(8.dp))
                                        .clickable {
                                            selectedVoice = id
                                            viewModel.liveService.selectedVoiceName = id
                                        }
                                        .padding(horizontal = 8.dp, vertical = 6.dp)
                                ) {
                                    Text(text = id, color = if (isVSelected) NeonCyan else TextGrayMuted, fontSize = 11.sp, fontWeight = FontWeight.SemiBold)
                                }
                            }
                        }
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text("Auto-Speak Text Responses", color = TextWhite, fontSize = 14.sp, fontWeight = FontWeight.Medium)
                            Text("Read chat responses aloud automatically", color = TextGrayMuted, fontSize = 12.sp)
                        }
                        Switch(
                            checked = autoSpeak,
                            onCheckedChange = { viewModel.autoSpeakResponses.value = it },
                            colors = SwitchDefaults.colors(
                                checkedThumbColor = DeepMidnight,
                                checkedTrackColor = ElectricBlue,
                                uncheckedThumbColor = TextGrayMuted,
                                uncheckedTrackColor = SurfaceDarkElevated
                            )
                        )
                    }

                    // Speech Rate Slider
                    Column {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text("Standard Speech Speed", color = TextWhite, fontSize = 13.sp)
                            Text(String.format("%.2fx", speechRate), color = NeonCyan, fontSize = 13.sp)
                        }
                        Slider(
                            value = speechRate,
                            onValueChange = {
                                speechRate = it
                                viewModel.ttsService.speechRate = it
                            },
                            valueRange = 0.75f..1.5f,
                            colors = SliderDefaults.colors(
                                thumbColor = ElectricBlue,
                                activeTrackColor = ElectricBlue,
                                inactiveTrackColor = SurfaceDarkElevated
                            )
                        )
                    }
                }
            }

            // AI Memory & Personalization
            item {
                SettingsSectionHeader("AI MEMORY & INTELLIGENCE")
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(16.dp))
                        .background(SurfaceDark)
                        .border(1.dp, BorderDark, RoundedCornerShape(16.dp))
                        .clickable { viewModel.navigateTo(AppScreen.MEMORY) }
                        .padding(16.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.Psychology,
                                contentDescription = null,
                                tint = NeonCyan,
                                modifier = Modifier.size(24.dp)
                            )
                            Spacer(modifier = Modifier.width(12.dp))
                            Column {
                                Text("Manage AI Memories", color = TextWhite, fontSize = 14.sp, fontWeight = FontWeight.SemiBold)
                                Text("${memories.size} active saved memories", color = TextGrayMuted, fontSize = 12.sp)
                            }
                        }
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowForwardIos,
                            contentDescription = null,
                            tint = TextGrayMuted,
                            modifier = Modifier.size(14.dp)
                        )
                    }
                }
            }

            // Data Management
            item {
                SettingsSectionHeader("DATA & STORAGE")
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(16.dp))
                        .background(SurfaceDark)
                        .border(1.dp, BorderDark, RoundedCornerShape(16.dp))
                        .clickable { showClearHistoryDialog = true }
                        .padding(16.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.Delete,
                                contentDescription = null,
                                tint = CrimsonError,
                                modifier = Modifier.size(22.dp)
                            )
                            Spacer(modifier = Modifier.width(12.dp))
                            Column {
                                Text("Clear Conversation History", color = TextWhite, fontSize = 14.sp, fontWeight = FontWeight.SemiBold)
                                Text("Delete all local chat records", color = TextGrayMuted, fontSize = 12.sp)
                            }
                        }
                    }
                }
            }

            // About & Version
            item {
                SettingsSectionHeader("ABOUT MAX AI")
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(16.dp))
                        .background(SurfaceDark)
                        .border(1.dp, BorderDark, RoundedCornerShape(16.dp))
                        .padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text("Application", color = TextGrayLight, fontSize = 13.sp)
                        Text("MAX AI Assistant", color = TextWhite, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
                    }
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text("Version", color = TextGrayLight, fontSize = 13.sp)
                        Text("1.0.0 (Futuristic Edition)", color = NeonCyan, fontSize = 13.sp)
                    }
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text("AI Framework", color = TextGrayLight, fontSize = 13.sp)
                        Text("Google Gemini", color = ElectricBlue, fontSize = 13.sp)
                    }
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text("Storage Architecture", color = TextGrayLight, fontSize = 13.sp)
                        Text("Local Room DB (Encrypted Sandbox)", color = TextWhite, fontSize = 13.sp)
                    }
                }
            }
        }
    }

    if (showClearHistoryDialog) {
        AlertDialog(
            onDismissRequest = { showClearHistoryDialog = false },
            containerColor = SurfaceDarkElevated,
            title = { Text("Clear All History", color = TextWhite) },
            text = {
                Text("Are you sure you want to delete all saved conversations? This cannot be undone.", color = TextGrayLight)
            },
            confirmButton = {
                TextButton(
                    onClick = {
                        viewModel.clearAllConversations()
                        showClearHistoryDialog = false
                    }
                ) {
                    Text("Delete", color = CrimsonError)
                }
            },
            dismissButton = {
                TextButton(onClick = { showClearHistoryDialog = false }) {
                    Text("Cancel", color = TextGrayLight)
                }
            }
        )
    }
}

@Composable
private fun SettingsSectionHeader(title: String) {
    Text(
        text = title,
        color = NeonCyan,
        fontSize = 11.sp,
        fontWeight = FontWeight.Bold,
        letterSpacing = 1.sp,
        modifier = Modifier.padding(start = 4.dp, top = 8.dp, bottom = 4.dp)
    )
}
