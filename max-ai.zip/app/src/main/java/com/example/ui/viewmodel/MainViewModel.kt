package com.example.ui.viewmodel

import android.app.Application
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.util.Log
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.local.AppDatabase
import com.example.data.local.entity.ChatMessageEntity
import com.example.data.local.entity.ConversationEntity
import com.example.data.local.entity.MemoryEntity
import com.example.data.model.AssistantMode
import com.example.data.model.PhoneAction
import com.example.data.model.VoiceState
import com.example.data.repository.ChatRepository
import com.example.data.repository.GeminiRepository
import com.example.data.repository.MemoryRepository
import com.example.service.AndroidActionService
import com.example.service.GeminiLiveService
import com.example.service.LiveConnectionState
import com.example.service.SpeechService
import com.example.service.TtsService
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.io.ByteArrayOutputStream

enum class AppScreen {
    HOME,
    VOICE,
    HISTORY,
    MEMORY,
    SETTINGS
}

data class AttachedFile(
    val uri: Uri,
    val name: String,
    val sizeBytes: Long,
    val mimeType: String,
    val bytes: ByteArray,
    val isImage: Boolean
) {
    val formattedSize: String
        get() = when {
            sizeBytes < 1024 -> "$sizeBytes B"
            sizeBytes < 1024 * 1024 -> "${sizeBytes / 1024} KB"
            else -> String.format("%.1f MB", sizeBytes.toDouble() / (1024 * 1024))
        }

    override fun equals(other: Any?): Boolean {
        if (this === other) return true
        if (javaClass != other?.javaClass) return false
        other as AttachedFile
        return uri == other.uri
    }

    override fun hashCode(): Int = uri.hashCode()
}

class MainViewModel(application: Application) : AndroidViewModel(application) {

    private val db = AppDatabase.getInstance(application)
    private val chatRepo = ChatRepository(db)
    private val memoryRepo = MemoryRepository(db)
    val geminiRepo = GeminiRepository()
    val speechService = SpeechService(application)
    val ttsService = TtsService(application)
    val liveService = GeminiLiveService(application)
    val actionService = AndroidActionService(application)

    // Voice Engine Selector (True: Gemini Live API WebSocket stream; False: Mode A SpeechRecognizer/TTS)
    val useGeminiLiveApi = MutableStateFlow(true)

    // Navigation state
    private val _currentScreen = MutableStateFlow(AppScreen.HOME)
    val currentScreen: StateFlow<AppScreen> = _currentScreen.asStateFlow()

    // Active conversation
    private val _currentConversationId = MutableStateFlow<Long?>(null)
    val currentConversationId: StateFlow<Long?> = _currentConversationId.asStateFlow()

    private val _currentConversationTitle = MutableStateFlow("New Chat")
    val currentConversationTitle: StateFlow<String> = _currentConversationTitle.asStateFlow()

    private val _messages = MutableStateFlow<List<ChatMessageEntity>>(emptyList())
    val messages: StateFlow<List<ChatMessageEntity>> = _messages.asStateFlow()

    // Mode
    private val _assistantMode = MutableStateFlow(AssistantMode.CHAT)
    val assistantMode: StateFlow<AssistantMode> = _assistantMode.asStateFlow()

    // Input state
    private val _inputText = MutableStateFlow("")
    val inputText: StateFlow<String> = _inputText.asStateFlow()

    private val _attachedFile = MutableStateFlow<AttachedFile?>(null)
    val attachedFile: StateFlow<AttachedFile?> = _attachedFile.asStateFlow()

    private val _attachmentError = MutableStateFlow<String?>(null)
    val attachmentError: StateFlow<String?> = _attachmentError.asStateFlow()

    // Backward-compatible alias for attachedImage
    val attachedImage: StateFlow<AttachedFile?> = _attachedFile.asStateFlow()

    // Generation state
    private val _isGenerating = MutableStateFlow(false)
    val isGenerating: StateFlow<Boolean> = _isGenerating.asStateFlow()

    private var generationJob: Job? = null

    // Voice mode state
    private val _voiceState = MutableStateFlow(VoiceState.READY)
    val voiceState: StateFlow<VoiceState> = _voiceState.asStateFlow()

    private val _voiceTranscript = MutableStateFlow("")
    val voiceTranscript: StateFlow<String> = _voiceTranscript.asStateFlow()

    // Smart Action confirmation dialog
    private val _pendingAction = MutableStateFlow<PhoneAction?>(null)
    val pendingAction: StateFlow<PhoneAction?> = _pendingAction.asStateFlow()

    // Settings
    val isDarkTheme = MutableStateFlow(true)
    val autoSpeakResponses = MutableStateFlow(false)
    val isMemoryEnabled = MutableStateFlow(true)
    val webSearchEnabled = MutableStateFlow(false)

    // History and Memories flow from Room
    val conversations: StateFlow<List<ConversationEntity>> = chatRepo.getAllConversations()
        .stateIn(viewModelScope, SharingStarted.Lazily, emptyList())

    val memories: StateFlow<List<MemoryEntity>> = memoryRepo.getAllMemories()
        .stateIn(viewModelScope, SharingStarted.Lazily, emptyList())

    init {
        // Setup speech recognition listener
        speechService.onSpeechCompleted = { text ->
            _voiceTranscript.value = text
            if (_currentScreen.value == AppScreen.VOICE) {
                // In live voice mode, automatically submit speech to MAX
                handleVoiceTurn(text)
            } else {
                _inputText.value = text
            }
        }

        // Setup TTS listener
        ttsService.onSpeechFinished = {
            if (_voiceState.value == VoiceState.SPEAKING) {
                _voiceState.value = VoiceState.READY
            }
        }

        // Collect speech listening state
        viewModelScope.launch {
            speechService.isListening.collect { listening ->
                if (listening) {
                    _voiceState.value = VoiceState.LISTENING
                } else if (_voiceState.value == VoiceState.LISTENING) {
                    _voiceState.value = VoiceState.READY
                }
            }
        }

        // Collect TTS speaking state
        viewModelScope.launch {
            ttsService.isSpeaking.collect { speaking ->
                if (speaking) {
                    _voiceState.value = VoiceState.SPEAKING
                } else if (_voiceState.value == VoiceState.SPEAKING) {
                    _voiceState.value = VoiceState.READY
                }
            }
        }

        // Setup Gemini Live turn completion listener
        liveService.onSessionTurnCompleted = { turnText ->
            viewModelScope.launch {
                val convId = _currentConversationId.value ?: return@launch
                val (cleanText, action) = geminiRepo.extractActionFromText(turnText)
                if (cleanText.isNotBlank()) {
                    chatRepo.insertMessage(
                        ChatMessageEntity(
                            conversationId = convId,
                            role = "model",
                            text = cleanText
                        )
                    )
                }
                if (action != null) {
                    handleDetectedAction(action)
                }
            }
        }

        // Seed initial conversation
        startNewConversation()
    }

    fun navigateTo(screen: AppScreen) {
        if (_currentScreen.value == AppScreen.VOICE && screen != AppScreen.VOICE) {
            liveService.stopSession()
            speechService.stopListening()
            ttsService.stop()
            _voiceState.value = VoiceState.READY
        } else if (screen == AppScreen.VOICE) {
            if (useGeminiLiveApi.value) {
                startLiveVoiceSession()
            }
        }
        _currentScreen.value = screen
    }

    fun startLiveVoiceSession() {
        viewModelScope.launch {
            val activeMemories = if (isMemoryEnabled.value) {
                memoryRepo.getMemoriesList().map { it.content }
            } else emptyList()
            val systemPrompt = geminiRepo.buildSystemPrompt(_assistantMode.value, activeMemories)
            liveService.startSession(systemPrompt)
        }
    }

    fun stopLiveVoiceSession() {
        liveService.stopSession()
    }

    fun toggleLiveVoiceMic() {
        liveService.toggleMute()
    }

    fun interruptLiveVoice() {
        liveService.interruptPlayback()
    }

    fun setAssistantMode(mode: AssistantMode) {
        _assistantMode.value = mode
    }

    fun setInputText(text: String) {
        _inputText.value = text
    }

    fun attachFile(uri: Uri) {
        viewModelScope.launch {
            try {
                val context = getApplication<Application>()
                var fileName = "Document"
                var fileSize = 0L

                val cursor = context.contentResolver.query(uri, null, null, null, null)
                cursor?.use {
                    if (it.moveToFirst()) {
                        val nameIndex = it.getColumnIndex(android.provider.OpenableColumns.DISPLAY_NAME)
                        val sizeIndex = it.getColumnIndex(android.provider.OpenableColumns.SIZE)
                        if (nameIndex != -1) fileName = it.getString(nameIndex) ?: "Document"
                        if (sizeIndex != -1) fileSize = it.getLong(sizeIndex)
                    }
                }

                // File size limit: 15 MB
                if (fileSize > 15 * 1024 * 1024) {
                    _attachmentError.value = "File exceeds 15 MB limit. Please select a smaller file."
                    return@launch
                }

                val mimeType = context.contentResolver.getType(uri) ?: when {
                    fileName.endsWith(".pdf", ignoreCase = true) -> "application/pdf"
                    fileName.endsWith(".txt", ignoreCase = true) -> "text/plain"
                    fileName.endsWith(".md", ignoreCase = true) -> "text/markdown"
                    fileName.endsWith(".json", ignoreCase = true) -> "application/json"
                    fileName.endsWith(".csv", ignoreCase = true) -> "text/csv"
                    fileName.endsWith(".png", ignoreCase = true) -> "image/png"
                    fileName.endsWith(".jpg", ignoreCase = true) || fileName.endsWith(".jpeg", ignoreCase = true) -> "image/jpeg"
                    else -> "application/octet-stream"
                }

                val isImage = mimeType.startsWith("image/")

                val inputStream = context.contentResolver.openInputStream(uri)
                val originalBytes = inputStream?.readBytes() ?: return@launch

                val processedBytes = if (isImage) {
                    val bitmap = BitmapFactory.decodeByteArray(originalBytes, 0, originalBytes.size)
                    val maxDim = 1024
                    val scaled = if (bitmap != null && (bitmap.width > maxDim || bitmap.height > maxDim)) {
                        val ratio = maxDim.toFloat() / maxOf(bitmap.width, bitmap.height)
                        Bitmap.createScaledBitmap(bitmap, (bitmap.width * ratio).toInt(), (bitmap.height * ratio).toInt(), true)
                    } else bitmap

                    if (scaled != null) {
                        val bos = ByteArrayOutputStream()
                        scaled.compress(Bitmap.CompressFormat.JPEG, 85, bos)
                        bos.toByteArray()
                    } else originalBytes
                } else {
                    originalBytes
                }

                _attachmentError.value = null
                _attachedFile.value = AttachedFile(
                    uri = uri,
                    name = fileName,
                    sizeBytes = fileSize.takeIf { it > 0 } ?: originalBytes.size.toLong(),
                    mimeType = mimeType,
                    bytes = processedBytes,
                    isImage = isImage
                )
            } catch (e: Exception) {
                Log.e("MainViewModel", "Failed to attach file", e)
                _attachmentError.value = "Could not open file: ${e.message}"
            }
        }
    }

    fun attachImage(uri: Uri) {
        attachFile(uri)
    }

    fun removeAttachedFile() {
        _attachedFile.value = null
        _attachmentError.value = null
    }

    fun removeAttachedImage() {
        removeAttachedFile()
    }

    fun startNewConversation() {
        viewModelScope.launch {
            val convId = chatRepo.createConversation(
                title = "New Chat",
                mode = _assistantMode.value.name
            )
            _currentConversationId.value = convId
            _currentConversationTitle.value = "New Chat"
            loadMessages(convId)
        }
    }

    fun selectConversation(conversation: ConversationEntity) {
        _currentConversationId.value = conversation.id
        _currentConversationTitle.value = conversation.title
        _assistantMode.value = try {
            AssistantMode.valueOf(conversation.mode)
        } catch (e: Exception) {
            AssistantMode.CHAT
        }
        loadMessages(conversation.id)
        navigateTo(AppScreen.HOME)
    }

    private fun loadMessages(conversationId: Long) {
        viewModelScope.launch {
            chatRepo.getMessages(conversationId).collect { msgList ->
                _messages.value = msgList
            }
        }
    }

    fun sendMessage(customPrompt: String? = null) {
        val promptToSend = (customPrompt ?: _inputText.value).trim()
        val currentFile = _attachedFile.value
        if (promptToSend.isEmpty() && currentFile == null) return

        val convId = _currentConversationId.value ?: return

        // Clear input state immediately
        _inputText.value = ""
        _attachedFile.value = null

        viewModelScope.launch {
            // Save user message in Room
            val userMsg = ChatMessageEntity(
                conversationId = convId,
                role = "user",
                text = promptToSend,
                imageUri = if (currentFile?.isImage == true) currentFile.uri.toString() else null,
                fileName = currentFile?.name,
                fileMimeType = currentFile?.mimeType
            )
            chatRepo.insertMessage(userMsg)

            // Auto-update conversation title if first message
            if (_currentConversationTitle.value == "New Chat") {
                val newTitle = promptToSend.take(30)
                _currentConversationTitle.value = newTitle
                chatRepo.updateConversationTitle(convId, newTitle)
            }

            // Prepare memory context
            val activeMemories = if (isMemoryEnabled.value) {
                memoryRepo.getMemoriesList().map { it.content }
            } else emptyList()

            // Prepare history pairs
            val pastTurns = _messages.value.map { it.role to it.text }

            _isGenerating.value = true

            // Insert initial empty placeholder for model response in database
            val modelMsgId = chatRepo.insertMessage(
                ChatMessageEntity(
                    conversationId = convId,
                    role = "model",
                    text = ""
                )
            )

            val fullResponseBuilder = StringBuilder()
            var extractedSourcesJson: String? = null

            generationJob = launch {
                geminiRepo.streamChat(
                    history = pastTurns,
                    latestPrompt = promptToSend,
                    fileBytes = currentFile?.bytes,
                    fileMimeType = currentFile?.mimeType,
                    fileName = currentFile?.name,
                    mode = _assistantMode.value,
                    memories = activeMemories,
                    useSearch = webSearchEnabled.value,
                    onSourcesExtracted = { sources ->
                        if (sources.isNotEmpty()) {
                            val jsonArray = org.json.JSONArray()
                            sources.forEach { s ->
                                jsonArray.put(org.json.JSONObject().apply {
                                    put("title", s.title)
                                    put("uri", s.uri)
                                })
                            }
                            extractedSourcesJson = jsonArray.toString()
                        }
                    }
                ).collect { chunk ->
                    fullResponseBuilder.append(chunk)
                    val currentText = fullResponseBuilder.toString()
                    chatRepo.updateMessage(
                        ChatMessageEntity(
                            id = modelMsgId,
                            conversationId = convId,
                            role = "model",
                            text = currentText,
                            sourcesJson = extractedSourcesJson
                        )
                    )
                }

                _isGenerating.value = false

                val finalOutput = fullResponseBuilder.toString()
                // Check if smart action is embedded
                val (cleanText, action) = geminiRepo.extractActionFromText(finalOutput)
                chatRepo.updateMessage(
                    ChatMessageEntity(
                        id = modelMsgId,
                        conversationId = convId,
                        role = "model",
                        text = cleanText,
                        sourcesJson = extractedSourcesJson
                    )
                )
                if (action != null) {
                    handleDetectedAction(action)
                }

                // If auto-speak is enabled, read response aloud
                if (autoSpeakResponses.value && cleanText.isNotBlank()) {
                    ttsService.speak(cleanText)
                }
            }
        }
    }

    private fun handleVoiceTurn(userUtterance: String) {
        val convId = _currentConversationId.value ?: return
        if (userUtterance.isBlank()) return

        viewModelScope.launch {
            _voiceState.value = VoiceState.THINKING

            // Insert user speech into chat
            chatRepo.insertMessage(
                ChatMessageEntity(
                    conversationId = convId,
                    role = "user",
                    text = userUtterance
                )
            )

            val activeMemories = if (isMemoryEnabled.value) {
                memoryRepo.getMemoriesList().map { it.content }
            } else emptyList()

            val pastTurns = _messages.value.map { it.role to it.text }

            val response = geminiRepo.generateResponse(
                history = pastTurns,
                latestPrompt = userUtterance,
                mode = _assistantMode.value,
                memories = activeMemories,
                useSearch = webSearchEnabled.value
            )

            // Insert model answer
            chatRepo.insertMessage(
                ChatMessageEntity(
                    conversationId = convId,
                    role = "model",
                    text = response.text,
                    isError = response.isError
                )
            )

            if (response.detectedAction != null) {
                handleDetectedAction(response.detectedAction)
            }

            // Speak the response aloud in voice mode
            _voiceState.value = VoiceState.SPEAKING
            ttsService.speak(response.text)
        }
    }

    fun handleDetectedAction(action: PhoneAction) {
        if (action.requiresConfirmation) {
            _pendingAction.value = action
        } else {
            actionService.executeAction(action)
        }
    }

    fun confirmPendingAction() {
        _pendingAction.value?.let {
            actionService.executeAction(it)
        }
        _pendingAction.value = null
    }

    fun dismissPendingAction() {
        _pendingAction.value = null
    }

    fun cancelGeneration() {
        generationJob?.cancel()
        _isGenerating.value = false
    }

    fun toggleVoiceListening() {
        if (speechService.isListening.value) {
            speechService.stopListening()
            _voiceState.value = VoiceState.READY
        } else {
            ttsService.stop()
            speechService.startListening()
            _voiceState.value = VoiceState.LISTENING
        }
    }

    fun speakMessage(text: String) {
        if (ttsService.isSpeaking.value) {
            ttsService.stop()
        } else {
            ttsService.speak(text)
        }
    }

    fun deleteConversation(id: Long) {
        viewModelScope.launch {
            chatRepo.deleteConversation(id)
            if (_currentConversationId.value == id) {
                startNewConversation()
            }
        }
    }

    fun updateConversationTitle(id: Long, newTitle: String) {
        viewModelScope.launch {
            chatRepo.updateConversationTitle(id, newTitle)
            if (_currentConversationId.value == id) {
                _currentConversationTitle.value = newTitle
            }
        }
    }

    fun clearAllConversations() {
        viewModelScope.launch {
            chatRepo.clearAllConversations()
            startNewConversation()
        }
    }

    fun addMemory(content: String, category: String = "general") {
        viewModelScope.launch {
            if (content.isNotBlank()) {
                memoryRepo.addMemory(content, category)
            }
        }
    }

    fun deleteMemory(id: Long) {
        viewModelScope.launch {
            memoryRepo.deleteMemory(id)
        }
    }

    fun clearAllMemories() {
        viewModelScope.launch {
            memoryRepo.clearAll()
        }
    }

    override fun onCleared() {
        super.onCleared()
        liveService.destroy()
        speechService.destroy()
        ttsService.destroy()
        generationJob?.cancel()
    }
}
