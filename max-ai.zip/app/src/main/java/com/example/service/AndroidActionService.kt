package com.example.service

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.util.Log
import android.widget.Toast
import com.example.data.model.PhoneAction

class AndroidActionService(private val context: Context) {

    fun executeAction(action: PhoneAction): Boolean {
        return try {
            when (action) {
                is PhoneAction.OpenApp -> openApp(action)
                is PhoneAction.OpenSettings -> openSettings(action)
                is PhoneAction.CallPhone -> callPhone(action)
                is PhoneAction.SendSms -> sendSms(action)
                is PhoneAction.OpenMapLocation -> openMapLocation(action)
                is PhoneAction.OpenWebUrl -> openWebUrl(action)
            }
        } catch (e: Exception) {
            Log.e("ActionService", "Failed to execute action: ${action.title}", e)
            Toast.makeText(context, "Could not perform action: ${e.message}", Toast.LENGTH_SHORT).show()
            false
        }
    }

    private fun openApp(action: PhoneAction.OpenApp): Boolean {
        val pm = context.packageManager
        val packageName = action.packageName

        if (!packageName.isNullOrBlank()) {
            val launchIntent = pm.getLaunchIntentForPackage(packageName)
            if (launchIntent != null) {
                launchIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                context.startActivity(launchIntent)
                return true
            }
        }

        // Generic intents for common apps
        when (action.appName.lowercase()) {
            "camera" -> {
                val intent = Intent(android.provider.MediaStore.ACTION_IMAGE_CAPTURE).apply {
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
                context.startActivity(intent)
                return true
            }
            "calculator" -> {
                val intent = Intent().apply {
                    setAction(Intent.ACTION_MAIN)
                    addCategory(Intent.CATEGORY_APP_CALCULATOR)
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
                if (intent.resolveActivity(pm) != null) {
                    context.startActivity(intent)
                    return true
                }
            }
            "calendar" -> {
                val intent = Intent().apply {
                    setAction(Intent.ACTION_MAIN)
                    addCategory(Intent.CATEGORY_APP_CALENDAR)
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
                if (intent.resolveActivity(pm) != null) {
                    context.startActivity(intent)
                    return true
                }
            }
            "maps" -> {
                val intent = Intent(Intent.ACTION_VIEW, Uri.parse("geo:0,0?q=")).apply {
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
                context.startActivity(intent)
                return true
            }
            "browser" -> {
                val intent = Intent(Intent.ACTION_VIEW, Uri.parse("https://www.google.com")).apply {
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
                context.startActivity(intent)
                return true
            }
        }

        Toast.makeText(context, "${action.appName} is not installed or cannot be opened", Toast.LENGTH_SHORT).show()
        return false
    }

    private fun openSettings(action: PhoneAction.OpenSettings): Boolean {
        val intent = Intent(action.actionIntent).apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        context.startActivity(intent)
        return true
    }

    private fun callPhone(action: PhoneAction.CallPhone): Boolean {
        // Safe ACTION_DIAL intent so user reviews the number on dialer without silent background dialing
        val intent = Intent(Intent.ACTION_DIAL).apply {
            data = Uri.parse("tel:${action.phoneNumber}")
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        context.startActivity(intent)
        return true
    }

    private fun sendSms(action: PhoneAction.SendSms): Boolean {
        // Opens SMS application with prefilled message body
        val intent = Intent(Intent.ACTION_SENDTO).apply {
            data = Uri.parse("smsto:${action.phoneNumber}")
            putExtra("sms_body", action.messageBody)
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        context.startActivity(intent)
        return true
    }

    private fun openMapLocation(action: PhoneAction.OpenMapLocation): Boolean {
        val encoded = Uri.encode(action.query)
        val intent = Intent(Intent.ACTION_VIEW, Uri.parse("geo:0,0?q=$encoded")).apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        context.startActivity(intent)
        return true
    }

    private fun openWebUrl(action: PhoneAction.OpenWebUrl): Boolean {
        var url = action.url
        if (!url.startsWith("http://") && !url.startsWith("https://")) {
            url = "https://$url"
        }
        val intent = Intent(Intent.ACTION_VIEW, Uri.parse(url)).apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        context.startActivity(intent)
        return true
    }
}
