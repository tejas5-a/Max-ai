package com.example.service

import android.annotation.SuppressLint
import android.content.Context
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioRecord
import android.media.AudioTrack
import android.media.MediaRecorder
import android.util.Base64
import android.util.Log
import com.example.BuildConfig
import com.example.data.model.VoiceState
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.Response
import okhttp3.WebSocket
import okhttp3.WebSocketListener
import org.json.JSONArray
import org.json.JSONObject
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.util.concurrent.ConcurrentLinkedQueue
import java.util.concurrent.TimeUnit
import kotlin.math.sqrt

enum class LiveConnectionState(val label: String) {
    DISCONNECTED("Disconnected"),
    CONNECTING("Connecting to Gemini Live..."),
    LIVE("Gemini Live: Connected"),
    RECONNECTING("Reconnecting..."),
    ERROR("Connection Error")
}

class GeminiLiveService(private val context: Context) {

    private val tag = "GeminiLiveService"

    // Audio format specifications for Gemini Live API
    // Input: 16kHz 16-bit mono PCM
    private val inputSampleRate = 16000
    // Output: 24kHz 16-bit mono PCM
    private val outputSampleRate = 24000

    private val client = OkHttpClient.Builder()
        .pingInterval(20, TimeUnit.SECONDS)
        .connectTimeout(30, TimeUnit.SECONDS)
        .readTimeout(30, TimeUnit.SECONDS)
        .build()

    private var webSocket: WebSocket? = null
    private var audioRecord: AudioRecord? = null
    private var audioTrack: AudioTrack? = null

    private var recordJob: Job? = null
    private var playJob: Job? = null
    private val coroutineScope = CoroutineScope(Dispatchers.IO)

    private val audioQueue = ConcurrentLinkedQueue<ByteArray>()

    // State Flows
    private val _connectionState = MutableStateFlow(LiveConnectionState.DISCONNECTED)
    val connectionState: StateFlow<LiveConnectionState> = _connectionState.asStateFlow()

    private val _voiceState = MutableStateFlow(VoiceState.READY)
    val voiceState: StateFlow<VoiceState> = _voiceState.asStateFlow()

    private val _rmsLevel = MutableStateFlow(0f)
    val rmsLevel: StateFlow<Float> = _rmsLevel.asStateFlow()

    private val _liveTranscript = MutableStateFlow("")
    val liveTranscript: StateFlow<String> = _liveTranscript.asStateFlow()

    private val _userTranscript = MutableStateFlow("")
    val userTranscript: StateFlow<String> = _userTranscript.asStateFlow()

    private val _isMuted = MutableStateFlow(false)
    val isMuted: StateFlow<Boolean> = _isMuted.asStateFlow()

    private val _errorMessage = MutableStateFlow<String?>(null)
    val errorMessage: StateFlow<String?> = _errorMessage.asStateFlow()

    var liveModel: String = "models/gemini-2.5-flash-native-audio-preview-12-2025"
    var selectedVoiceName: String = "Aoede" // Supported prebuilt voices: Aoede, Puck, Charon, Kore, Fenrir

    var onActionDetected: ((String) -> Unit)? = null
    var onSessionTurnCompleted: ((String) -> Unit)? = null

    private val fullTurnTextAccumulator = StringBuilder()

    private fun getApiKey(): String {
        return try {
            BuildConfig.GEMINI_API_KEY
        } catch (e: Exception) {
            ""
        }
    }

    /**
     * Connects to the official Gemini Live WebSocket BidiGenerateContent endpoint.
     */
    fun startSession(systemPrompt: String) {
        stopSession()

        val apiKey = getApiKey()
        if (apiKey.isBlank() || apiKey == "MY_GEMINI_API_KEY") {
            _connectionState.value = LiveConnectionState.ERROR
            _errorMessage.value = "Gemini API key is missing. Configure GEMINI_API_KEY in Secrets."
            _voiceState.value = VoiceState.ERROR
            return
        }

        _connectionState.value = LiveConnectionState.CONNECTING
        _errorMessage.value = null
        _liveTranscript.value = ""
        _userTranscript.value = ""
        fullTurnTextAccumulator.clear()

        val endpoint = "wss://generativelanguage.googleapis.com/ws/google.ai.generativelanguage.v1beta.GenerativeService.BidiGenerateContent?key=$apiKey"

        val request = Request.Builder()
            .url(endpoint)
            .build()

        webSocket = client.newWebSocket(request, object : WebSocketListener() {
            override fun onOpen(webSocket: WebSocket, response: Response) {
                Log.d(tag, "WebSocket connected successfully. Sending BidiGenerateContentSetup...")
                _connectionState.value = LiveConnectionState.LIVE
                _voiceState.value = VoiceState.READY

                // Send Setup message immediately after handshake
                sendSetupMessage(webSocket, systemPrompt)

                // Start recording microphone audio and audio playback track
                initAudioTrack()
                startRecording()
            }

            override fun onMessage(webSocket: WebSocket, text: String) {
                handleServerMessage(text)
            }

            override fun onClosing(webSocket: WebSocket, code: Int, reason: String) {
                Log.d(tag, "WebSocket closing: $code / $reason")
                _connectionState.value = LiveConnectionState.DISCONNECTED
            }

            override fun onClosed(webSocket: WebSocket, code: Int, reason: String) {
                Log.d(tag, "WebSocket closed: $code / $reason")
                _connectionState.value = LiveConnectionState.DISCONNECTED
                _voiceState.value = VoiceState.READY
            }

            override fun onFailure(webSocket: WebSocket, t: Throwable, response: Response?) {
                Log.e(tag, "WebSocket connection failed: ${t.message}", t)
                _connectionState.value = LiveConnectionState.ERROR
                _voiceState.value = VoiceState.ERROR
                _errorMessage.value = "Live connection failed: ${t.localizedMessage ?: "Network error"}"
            }
        })
    }

    private fun sendSetupMessage(ws: WebSocket, systemPrompt: String) {
        try {
            val setupObj = JSONObject()
            val config = JSONObject()

            config.put("model", liveModel)

            // Generation config: Native Audio response modality & speech config
            val genConfig = JSONObject()
            val modalities = JSONArray()
            modalities.put("AUDIO")
            genConfig.put("responseModalities", modalities)

            val speechConfig = JSONObject()
            val voiceConfig = JSONObject()
            val prebuiltVoiceConfig = JSONObject()
            prebuiltVoiceConfig.put("voiceName", selectedVoiceName)
            voiceConfig.put("prebuiltVoiceConfig", prebuiltVoiceConfig)
            speechConfig.put("voiceConfig", voiceConfig)
            genConfig.put("speechConfig", speechConfig)

            config.put("generationConfig", genConfig)

            // System instruction
            if (systemPrompt.isNotBlank()) {
                val sysInst = JSONObject()
                val parts = JSONArray()
                parts.put(JSONObject().put("text", systemPrompt))
                sysInst.put("parts", parts)
                config.put("systemInstruction", sysInst)
            }

            setupObj.put("setup", config)

            val jsonString = setupObj.toString()
            Log.d(tag, "Sending setup: $jsonString")
            ws.send(jsonString)
        } catch (e: Exception) {
            Log.e(tag, "Error sending setup message", e)
        }
    }

    private fun handleServerMessage(jsonString: String) {
        try {
            val root = JSONObject(jsonString)

            if (root.has("serverContent")) {
                val serverContent = root.getJSONObject("serverContent")

                // Handle interruption / barge-in from model
                if (serverContent.optBoolean("interrupted", false)) {
                    Log.d(tag, "Model was interrupted by user voice activity (barge-in)")
                    interruptPlayback()
                }

                if (serverContent.has("modelTurn")) {
                    val modelTurn = serverContent.getJSONObject("modelTurn")
                    val parts = modelTurn.optJSONArray("parts")

                    if (parts != null) {
                        for (i in 0 until parts.length()) {
                            val part = parts.getJSONObject(i)

                            // 1. Text transcript piece
                            if (part.has("text")) {
                                val text = part.getString("text")
                                fullTurnTextAccumulator.append(text)
                                _liveTranscript.value = fullTurnTextAccumulator.toString()
                            }

                            // 2. Audio PCM data piece
                            if (part.has("inlineData")) {
                                val inlineData = part.getJSONObject("inlineData")
                                val base64Audio = inlineData.getString("data")
                                val pcmBytes = Base64.decode(base64Audio, Base64.NO_WRAP)

                                if (pcmBytes != null && pcmBytes.isNotEmpty()) {
                                    audioQueue.offer(pcmBytes)
                                    _voiceState.value = VoiceState.SPEAKING
                                }
                            }
                        }
                    }
                }

                // Handle turn completion
                if (serverContent.optBoolean("turnComplete", false)) {
                    val completedText = fullTurnTextAccumulator.toString()
                    Log.d(tag, "Turn complete: $completedText")
                    if (completedText.isNotBlank()) {
                        onSessionTurnCompleted?.invoke(completedText)
                    }
                    fullTurnTextAccumulator.clear()
                    if (audioQueue.isEmpty()) {
                        _voiceState.value = VoiceState.READY
                    }
                }
            }
        } catch (e: Exception) {
            Log.e(tag, "Error handling server message: ${e.message}", e)
        }
    }

    /**
     * Initializes AudioTrack for low-latency PCM 24kHz audio playback.
     */
    private fun initAudioTrack() {
        try {
            audioTrack?.release()

            val minBufferSize = AudioTrack.getMinBufferSize(
                outputSampleRate,
                AudioFormat.CHANNEL_OUT_MONO,
                AudioFormat.ENCODING_PCM_16BIT
            )
            val bufferSize = maxOf(minBufferSize * 2, 4096)

            audioTrack = AudioTrack.Builder()
                .setAudioAttributes(
                    AudioAttributes.Builder()
                        .setUsage(AudioAttributes.USAGE_ASSISTANCE_SONIFICATION)
                        .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                        .build()
                )
                .setAudioFormat(
                    AudioFormat.Builder()
                        .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                        .setSampleRate(outputSampleRate)
                        .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
                        .build()
                )
                .setBufferSizeInBytes(bufferSize)
                .setTransferMode(AudioTrack.MODE_STREAM)
                .build()

            audioTrack?.play()

            // Playback consumer loop
            playJob = coroutineScope.launch {
                while (isActive) {
                    val chunk = audioQueue.poll()
                    if (chunk != null) {
                        // Calculate output RMS to pulse orb to model speech
                        computeRms(chunk)
                        audioTrack?.write(chunk, 0, chunk.size)
                    } else {
                        if (_voiceState.value == VoiceState.SPEAKING && audioQueue.isEmpty()) {
                            _voiceState.value = VoiceState.READY
                            _rmsLevel.value = 0f
                        }
                        kotlinx.coroutines.delay(20)
                    }
                }
            }
        } catch (e: Exception) {
            Log.e(tag, "Failed to initialize AudioTrack", e)
        }
    }

    /**
     * Starts continuous AudioRecord loop capturing 16kHz 16-bit PCM and streaming to Gemini Live.
     */
    @SuppressLint("MissingPermission")
    private fun startRecording() {
        recordJob?.cancel()

        val minBuf = AudioRecord.getMinBufferSize(
            inputSampleRate,
            AudioFormat.CHANNEL_IN_MONO,
            AudioFormat.ENCODING_PCM_16BIT
        )
        val bufferSize = maxOf(minBuf * 2, 2048)

        try {
            audioRecord = AudioRecord(
                MediaRecorder.AudioSource.VOICE_COMMUNICATION,
                inputSampleRate,
                AudioFormat.CHANNEL_IN_MONO,
                AudioFormat.ENCODING_PCM_16BIT,
                bufferSize
            )

            audioRecord?.startRecording()

            recordJob = coroutineScope.launch {
                val buffer = ByteArray(2048) // ~64ms of audio

                while (isActive && audioRecord?.recordingState == AudioRecord.RECORDSTATE_RECORDING) {
                    if (_isMuted.value) {
                        kotlinx.coroutines.delay(50)
                        continue
                    }

                    val read = audioRecord?.read(buffer, 0, buffer.size) ?: 0
                    if (read > 0) {
                        val inputData = buffer.copyOf(read)
                        val rms = computeRms(inputData)

                        // If user begins speaking loudly during model playback, trigger immediate local barge-in
                        if (rms > 0.35f && _voiceState.value == VoiceState.SPEAKING) {
                            interruptPlayback()
                        }

                        if (_voiceState.value != VoiceState.SPEAKING) {
                            _voiceState.value = if (rms > 0.08f) VoiceState.LISTENING else VoiceState.READY
                        }

                        // Send realtime audio chunk over WebSocket
                        val base64Chunk = Base64.encodeToString(inputData, Base64.NO_WRAP)
                        sendAudioChunk(base64Chunk)
                    }
                }
            }
        } catch (e: Exception) {
            Log.e(tag, "Failed to start AudioRecord", e)
            _errorMessage.value = "Microphone error: ${e.message}"
        }
    }

    private fun sendAudioChunk(base64Data: String) {
        val ws = webSocket ?: return
        try {
            val root = JSONObject()
            val realtimeInput = JSONObject()
            val mediaChunks = JSONArray()
            val chunk = JSONObject()
            chunk.put("mimeType", "audio/pcm;rate=16000")
            chunk.put("data", base64Data)
            mediaChunks.put(chunk)
            realtimeInput.put("mediaChunks", mediaChunks)
            root.put("realtimeInput", realtimeInput)

            ws.send(root.toString())
        } catch (e: Exception) {
            Log.e(tag, "Error sending audio chunk", e)
        }
    }

    /**
     * Immediately interrupts and flushes AudioTrack buffer for seamless barge-in.
     */
    fun interruptPlayback() {
        audioQueue.clear()
        try {
            audioTrack?.pause()
            audioTrack?.flush()
            audioTrack?.play()
        } catch (e: Exception) {
            Log.w(tag, "Error flushing AudioTrack", e)
        }
        _voiceState.value = VoiceState.READY
        _rmsLevel.value = 0f
    }

    private fun computeRms(pcmBytes: ByteArray): Float {
        var sum = 0.0
        val shortBuffer = ByteBuffer.wrap(pcmBytes).order(ByteOrder.LITTLE_ENDIAN).asShortBuffer()
        val numSamples = shortBuffer.remaining()
        if (numSamples == 0) return 0f

        while (shortBuffer.hasRemaining()) {
            val sample = shortBuffer.get()
            sum += (sample * sample).toDouble()
        }
        val rms = sqrt(sum / numSamples)
        // Normalize 0..32768 to 0..1 range with scaling
        val normalized = (rms / 4000.0).coerceIn(0.0, 1.0).toFloat()
        _rmsLevel.value = normalized
        return normalized
    }

    fun toggleMute() {
        _isMuted.value = !_isMuted.value
    }

    fun stopSession() {
        recordJob?.cancel()
        recordJob = null
        playJob?.cancel()
        playJob = null

        try {
            audioRecord?.stop()
            audioRecord?.release()
            audioRecord = null
        } catch (e: Exception) {
            Log.w(tag, "AudioRecord cleanup error", e)
        }

        interruptPlayback()
        try {
            audioTrack?.stop()
            audioTrack?.release()
            audioTrack = null
        } catch (e: Exception) {
            Log.w(tag, "AudioTrack cleanup error", e)
        }

        try {
            webSocket?.close(1000, "Session ended by user")
            webSocket = null
        } catch (e: Exception) {
            Log.w(tag, "WebSocket close error", e)
        }

        _connectionState.value = LiveConnectionState.DISCONNECTED
        _voiceState.value = VoiceState.READY
        _rmsLevel.value = 0f
    }

    fun destroy() {
        stopSession()
    }
}
